-- phpMyAdmin SQL Dump
-- version 5.2.1
-- https://www.phpmyadmin.net/
--
-- Host: 127.0.0.1
-- Generation Time: Dec 10, 2023 at 05:08 PM
-- Server version: 10.4.28-MariaDB
-- PHP Version: 8.1.17

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
START TRANSACTION;
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- Database: `jotasi_db`
--

-- --------------------------------------------------------

--
-- Table structure for table `artikel`
--

CREATE TABLE `artikel` (
  `id_artikel` int(10) NOT NULL,
  `judul` varchar(255) NOT NULL,
  `informasi` varchar(1000) NOT NULL,
  `gambar` varchar(225) NOT NULL,
  `deskripsi` varchar(2000) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Dumping data for table `artikel`
--

INSERT INTO `artikel` (`id_artikel`, `judul`, `informasi`, `gambar`, `deskripsi`) VALUES
(3, 'Agrowisata Bhumi Merapi', '  Dari namanya saja mungkin kamu sudah bisa menebak bahwa wisata satu ini berada dalam kawasan lereng gunung merapi, lebih tepatnya di Jl. Kaliurang KM 20. Konsep Agrowisata sendiri bertujuan untuk menghadirkan tempat wisata yang menghibur sekaligus mengedukasi pengunjungnya.\r\n', 'b3.jpg', '\r\n        Objek wisata dengan luas sebesar 5,2 hektar ini menawarkan berbagai edukasi mengenai perkebunan dan peternakan. Beberapa kegiatan yang ditawarkan antara lain, melihat proses pembuatan kopi luwak, memerah susu kambing, mengolah susu sebagai yogurt dan es krim, termasuk kamu juga bisa membeli hasil kebun hidroponik di sana secara langsung.\r\n<br/><br/>\r\n        Tidak hanya kegiatan yang mengedukasi, di Agrowisata Bhumi Merapi juga tersedia berbagai spot foto menarik untuk kamu yang senang berswafoto ria. Harga tiket masuk Agrowisata Bhumi Merapi adalah sebesar Rp30.000 per pengunjung.\r\n<br/>\r\n        \r\n          <b>Alamat:</b> Jl. Kaliurang No.Km.20, Sawungan, Hargobinangun, Kec. Pakem, Kabupaten Sleman, Daerah Istimewa Yogyakarta 55582<br/>\r\n\r\n          <b> Jam operasional:</b> Setiap hari, 09.00–17.00WIB\r\n        '),
(5, 'Air Terjun Kedung Pedut', '  Bagi kamu yang mencari tempat wisata alam yang menyuguhkan pemandangan air terjun yang indah dan jernih, Air Terjun Kedung Pedut wajib masuk ke daftar tempat wisata yang harus kamu kunjungi di Jogja.', 'b5.jpg', '\r\n        Selain menawarkan pemandangan air terjun, tempat yang berlokasi di Kabupaten Kulonprogo ini juga memiliki fasilitas yang lengkap untuk para pengunjung seperti warung makan, gazebo, hingga flying fox.\r\n<br/><br/>\r\n        \r\n          <b>Alamat:</b> Jl. Kutogiri Gunung Kelir, Kembang, Jatimulyo, Kec. Girimulyo, Kabupaten Kulon Progo<br/>\r\n          <b>Jam Operasional: </b>Setiap hari, 08.00–16.00 WIB\r\n        '),
(21, 'CANDI PRAMBANAN', 'Candi Prambanan merupakan salah satu bukti peninggalan sejarah pada masa kerajaan hindu di indonesia tepatnya berada di pulau jawa. Bangunan sejarah ini dibangun pada abad ke 8 masehi. Candi hindu terbesar yang ada di indonesia ini telah ditetapkan sebagai situs warisan budaya dunia oleh UNESCO pada tahun 1991', 'tiket3.jpg', 'Lokasi dari Candi Prambanan sendiri berada di Taman Wisata Prambanan atau jika dari arah Pusat Kota Yogyakarta dapat menempuh jarak sekitar 17 km ke arah timur. Berada tepat di Desa Prambanan , Kecamatan Bokoharjo. Pada zaman dahulu daerah sini merupakan wilayah Bhumi Mataram, masyarakat sekitar menyebutnya sebagai sebutan lama wilayah Yogyakarta dan sekitarnya.'),
(22, 'Tebing Breksi', 'Taman wisata Tebing Breksi adalah sebuah tempat wisata alam di Jogja. Sesuai dengan namanya, tempat wisata ini merupakan perbukitan batuan breksi. Tebing batuan breksi yang memiliki corak yang indah menjadi daya tarik tersendiri bagi wisatawan.', 'tiket4.jpg', 'Sebelum menjadi tempat wisata, lokasi Taman Tebing Breksi sebelumnya adalah tempat penambangan batuan alam. Kegiatan penambangan ini dilakukan oleh masyarakat sekitar. Di sekitar lokasi penambangan terdapat tempat-tempat pemotongan batuan hasil penambangan untuk dijadikan bahan dekorasi bangunan.\r\n<br/><br/>\r\nSejak tahun 2014, kegiatan penambangan di tempat ini ditutup oleh pemerintah. Penutupan ini berdasarkan hasil kajian yang menyatakan bahwa batuan yang ada di lokasi penambangan ini merupakan batuan yang berasal dari aktivitas vulkanis Gunung Api Purba Nglanggeran. Kemudian lokasi penambangan ditetapkan sebagai tempat yang dilindungi dan tidak diperkenankan untuk dilakukan kegiatan penambangan.');

-- --------------------------------------------------------

--
-- Table structure for table `blog`
--

CREATE TABLE `blog` (
  `id` int(25) NOT NULL,
  `image_blog` varchar(100) NOT NULL,
  `judul_blog` varchar(100) NOT NULL,
  `deskripsi_blog` varchar(300) NOT NULL,
  `tanggal` varchar(225) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Dumping data for table `blog`
--

INSERT INTO `blog` (`id`, `image_blog`, `judul_blog`, `deskripsi_blog`, `tanggal`) VALUES
(2, 'blog1.2.jpg', 'Memperingati Hari Wayang Sedunia ', ' budaya wayang khususnya wayang kulit diakui oleh UNESCO sebagai warisan lisan yang indah dan berharga (Masterpiece of Oral and Intangible Heritage of Humanity).', '25 februari 2023'),
(3, 'background-bromo.jpg', '5 Hal yang Wajib Kamu Tahu Sebelum Wisata ke Jogja', 'Yogyakarta (sering juga disebut Yogya, Jogjakarta, atau Jogja) adalah destinasi wisata paling populer di Indonesia setelah Bali. Ini 5 hal yang wajib kamu ketahui', '24 November 2023'),
(6, 'pralogin3.jpeg', 'Gelar Penampil Pentas Seni Pelajar Jogja Museum Expo 2022', 'Kulon Progo. Dinas Kebudayaan (Kundha Kabudayan) Daerah Istimewa Yogyakarta (DIY) menggelar Jogja Museum Expo di Exhibition Hall Ground Floor Sleman City Hall.', '2023-12-20');

-- --------------------------------------------------------

--
-- Table structure for table `kuliner`
--

CREATE TABLE `kuliner` (
  `id` int(225) NOT NULL,
  `judul` varchar(225) NOT NULL,
  `gambar` varchar(225) NOT NULL,
  `deskripsi` varchar(225) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Dumping data for table `kuliner`
--

INSERT INTO `kuliner` (`id`, `judul`, `gambar`, `deskripsi`) VALUES
(1, 'Gudeg Pawon', 'kuliner2.jpg', ' tempat kuliner Jogja yang satu ini bertempat di dapur. Nah, loh, unik banget kan? Di ruangan yang berukuran sekira 10 x 6 meter ini, Kamu bisa mencicipi Gudeg Pawon yang legendaris banget. Di ruangan ini pula, gudeg diracik,'),
(2, 'Saoto Bathok Mbah Katro', 'kuliner3.jpg', 'Mencicipi kuliner mblusuk yang legendaris di Jogja, Saoto Bathok Mbah Katro, soto sapi dalam mangkok dari batok kelapa. Selengkapnya lihat di SAOTO BATHOK MBAH KATRO'),
(3, 'Kopi Klotok', 'kuliner1.jpg', 'Masakan yang disajikan memang bersahaja, seperti sayur lodeh terong, dll. Namun, rasanya sangat lezat dan harganya bersahabat, rata-rata di bawah Rp10.000.'),
(6, 'BAKPIA KUKUS TUGU JOGJA', 'kuliner5.jpg', 'Gudeg dan bakpia adalah oleh-oleh tradisional dari Jogja. Namun, sejak tahun 2017 hadir oleh-oleh kekinian yang langsung viral, yaitu Bakpia Kukus Tugu Jogja.'),
(7, 'Tengkleng Gajah', 'kuliner4.jpg', 'Tengkleng Gajah tak lain adalah tengkleng kambing muda yang disajikan dalam porsi besar, seperti gajah. Rasanya nikmat, dagingnya empuk dan porsinya yang melimpah.'),
(8, 'BAKMI JOWO MBAH GITO', 'kuliner6.jpg', 'Tak hanya kelezatan santapannya saja yang ditawarkan, namun juga suasana Jawa-tradisional yang membuat pengunjung akan mengarungi lorong waktu menuju masa silam.termasuk makanan yang di incer para pengunjung');

-- --------------------------------------------------------

--
-- Table structure for table `media`
--

CREATE TABLE `media` (
  `id` int(255) NOT NULL,
  `image_media` varchar(255) NOT NULL,
  `judul_media` varchar(225) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Dumping data for table `media`
--

INSERT INTO `media` (`id`, `image_media`, `judul_media`) VALUES
(11, 'tiket2.jpg', 'Keraton Ratu Boko'),
(13, 'tiket1.jpg', 'Candi Borobudur'),
(14, 'tiket7.jpg', 'Obelix Hills '),
(15, 'tiket5.jpg', 'Gamplong Studio Alam'),
(16, 'tiket6.jpg', 'Pantai Parangtritis'),
(18, 'tiket8.jpg', 'jeep merapi');

-- --------------------------------------------------------

--
-- Table structure for table `register`
--

CREATE TABLE `register` (
  `id` int(225) NOT NULL,
  `email` varchar(225) NOT NULL,
  `username` varchar(225) NOT NULL,
  `password` varchar(225) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Dumping data for table `register`
--

INSERT INTO `register` (`id`, `email`, `username`, `password`) VALUES
(1, 'dede@gmail.com', 'dede', '5df1bf9278e5fd1b897eb41e6f6e220b'),
(2, 'asd@gmail.com', 'asd', 'e2fc714c4727ee9395f324cd2e7f331f'),
(3, 'diena@gmail.com', 'diena', 'bf87e223f6d1b16b53455d3bbafe66b6'),
(4, 'sifa@gmail.com', 'sifa', '12f57858769fcb6b460ff6833b19de5a'),
(5, 'eve.holt@reqres.in', 'test', 'e10adc3949ba59abbe56e057f20f883e'),
(6, 'zulfansugeha18@gmail.com', 'upang', '37693cfc748049e45d87b8c7d8b9aacd');

-- --------------------------------------------------------

--
-- Table structure for table `review_kuliner`
--

CREATE TABLE `review_kuliner` (
  `id` int(50) NOT NULL,
  `userName` varchar(255) NOT NULL,
  `userReview` text NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Dumping data for table `review_kuliner`
--

INSERT INTO `review_kuliner` (`id`, `userName`, `userReview`) VALUES
(19, 'Diena ', 'Kerennn abiss\r\n');

-- --------------------------------------------------------

--
-- Table structure for table `tiket`
--

CREATE TABLE `tiket` (
  `gambar` varchar(255) NOT NULL,
  `tiket_desc` varchar(500) NOT NULL,
  `id` int(11) NOT NULL,
  `tiket_name` varchar(255) DEFAULT NULL,
  `tiket_price` int(11) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Dumping data for table `tiket`
--

INSERT INTO `tiket` (`gambar`, `tiket_desc`, `id`, `tiket_name`, `tiket_price`) VALUES
('tiket1.jpg', 'Jika Anda sedang mencari tujuan wisata populer di Yogyakarta, Candi Borobudur adalah pilihan yang bagus. Salah satunya Daya tarik utamanya', 1, 'Candi Borobudur', 50000),
('wisata7.jpg', 'Selain menawarkan pemandangan air terjun, tempat ini memiliki fasilitas yang lengkap untuk para pengunjung seperti warung makan, gazebo, hingga flying fox. ', 2, 'Air Terjun Kedung Pedut', 75000),
('tiket6.jpg', 'Parangtritis Beach is a tourist beach on the southern coast of Java, in the Bantul Regency within the Special Region of Yogyakarta, Indonesia. ', 3, 'Pantai Parangtritis', 100000),
('wisata5.png\r\n', 'Taman Sari Water Castle, also known as Taman Sari, is the site of a former royal garden of the Sultanate of Yogyakarta.', 4, 'Taman Sari ', 12000),
('tiket3.jpg', 'If you\'re planning a trip to Jogja, make sure to visit Prambanan Temple, a must-see tourist destination.', 5, 'Candi Prambanan', 29000),
('tiket4.jpg', 'Hits dan Kekinian, mungkin itulah yang bisa menggambarkan destinasi wisata Taman Tebing Breksi di Yogyakarta ini. bagai mana tidak', 6, 'TAMAN TEBING BREKSI ', 15000);

--
-- Indexes for dumped tables
--

--
-- Indexes for table `artikel`
--
ALTER TABLE `artikel`
  ADD PRIMARY KEY (`id_artikel`);

--
-- Indexes for table `blog`
--
ALTER TABLE `blog`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `kuliner`
--
ALTER TABLE `kuliner`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `media`
--
ALTER TABLE `media`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `register`
--
ALTER TABLE `register`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `review_kuliner`
--
ALTER TABLE `review_kuliner`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `tiket`
--
ALTER TABLE `tiket`
  ADD PRIMARY KEY (`id`);

--
-- AUTO_INCREMENT for dumped tables
--

--
-- AUTO_INCREMENT for table `artikel`
--
ALTER TABLE `artikel`
  MODIFY `id_artikel` int(10) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=25;

--
-- AUTO_INCREMENT for table `blog`
--
ALTER TABLE `blog`
  MODIFY `id` int(25) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=8;

--
-- AUTO_INCREMENT for table `kuliner`
--
ALTER TABLE `kuliner`
  MODIFY `id` int(225) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=11;

--
-- AUTO_INCREMENT for table `media`
--
ALTER TABLE `media`
  MODIFY `id` int(255) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=20;

--
-- AUTO_INCREMENT for table `register`
--
ALTER TABLE `register`
  MODIFY `id` int(225) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=7;

--
-- AUTO_INCREMENT for table `review_kuliner`
--
ALTER TABLE `review_kuliner`
  MODIFY `id` int(50) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=26;

--
-- AUTO_INCREMENT for table `tiket`
--
ALTER TABLE `tiket`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=8;
COMMIT;

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
