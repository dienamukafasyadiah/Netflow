
  let cartItems = [];

  // JavaScript function to add tickets to the cart
  function addToCart(ticketName, ticketPrice, ticketImage) {
    // Create or retrieve the cart array from local storage
    let cart = JSON.parse(localStorage.getItem("cart")) || [];

    // Check if the ticket is already in the cart
    let existingItem = cart.find((item) => item.name === ticketName);

    if (existingItem) {
      existingItem.quantity += 1; // If the ticket is already in the cart, increment the quantity
    } else {
      // If the ticket is not in the cart, add it to the cart with quantity 1
      cart.push({ name: ticketName, price: ticketPrice, gambar: ticketImage, quantity: 1 });
    }

    // Save the updated cart back to local storage
    localStorage.setItem("cart", JSON.stringify(cart));

    // Alert to show the ticket has been added to the cart (you can customize this)
    alert("Ticket added to cart!");
    console.log(cart);
    updateCartCount();
    displayCart(); // Update the displayed cart items
  }

  // JavaScript function to update cart count and display in the floating cart
  function updateCartCount() {
    let cart = JSON.parse(localStorage.getItem("cart")) || [];
    let cartCount = cart.length;

    // Display the cart count in the floating cart container
    document.getElementById("cartCount").innerText = cartCount;
  }

  // Function to display cart items
  function displayCart() {
    let cart = JSON.parse(localStorage.getItem("cart")) || [];
    let totalHarga = 0; // Add variable to store total price

    // Select the HTML element to display cart items
    let cartList = document.getElementById("cartList");
    cartList.innerHTML = ""; // Clear previous content

    if (cart.length === 0) {
      cartList.innerHTML = "<p>No items in the cart.</p>";
    } else {
      cart.forEach(function (item, index) {
        // Create HTML elements for each cart item
        let cartItem = document.createElement("div");
        cartItem.classList.add("cart-item");

        let itemName = document.createElement("span");
        itemName.textContent = item.name;

        let itemPrice = document.createElement("span");
        itemPrice.textContent = "Harga: Rp." + item.price;

        let gambar = document.createElement("img");
        gambar.src = item.gambar;

        let itemQuantity = document.createElement("input");
        itemQuantity.type = "number";
        itemQuantity.value = item.quantity || 1;
        itemQuantity.min = 1;
        itemQuantity.addEventListener("change", function () {
          // Update the quantity in the cart when changed
          cart[index].quantity = parseInt(itemQuantity.value);
          localStorage.setItem("cart", JSON.stringify(cart));
          displayCart(); // Update the displayed cart items
        });

        let deleteButton = document.createElement("button");
        deleteButton.textContent = "Delete";
        deleteButton.classList.add("delete-button");
        deleteButton.addEventListener("click", function () {
          // Remove item from the cart when delete button is clicked
          cart.splice(index, 1);
          localStorage.setItem("cart", JSON.stringify(cart));
          displayCart(); // Update the displayed cart items
          updateCartCount(); // Update the cart count after deleting an item
        });

        // Append elements to cartItem div
        cartItem.appendChild(itemName);
        cartItem.appendChild(itemPrice);
        cartItem.appendChild(gambar);
        cartItem.appendChild(itemQuantity);
        cartItem.appendChild(deleteButton);

        // Append cartItem to cartList
        cartList.appendChild(cartItem);

        // Calculate total price for each item and add to totalHarga
        let subtotal = item.price * item.quantity;
        totalHarga += subtotal;
      });

      // Add an element to display the total price
      let totalHargaElement = document.createElement("p");
      totalHargaElement.textContent = "Total Harga: Rp." + totalHarga.toFixed(2);
      cartList.appendChild(totalHargaElement);
    }
  }

  // Run the displayCart function when the page loads
  window.onload = function () {
    displayCart();
    updateCartCount();
  };

