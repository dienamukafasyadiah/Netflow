<?php
include "koneksi.php";
?>


<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0, maximum-scale=1.0, user0scalable=no">
    <title>Tiket</title>
    <link rel="stylesheet" href="../style/tiket.css">
    <link rel="preconnect" href="https://fonts.googleapis.com">
    <link href='https://unpkg.com/boxicons@2.1.4/css/boxicons.min.css' rel='stylesheet'>
<link rel="preconnect" href="https://fonts.gstatic.com" crossorigin>
<link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/5.15.1/css/all.min.css" integrity="sha512-+4zCK9k+qNFUR5X+cKL9EIR+ZOhtIloNl9GIKS57V1MyNsYpYcUrUeQc9vNfzsWfV28IaLL3i96P9sdNyeRssA==" crossorigin="anonymous" />
<link href="https://fonts.googleapis.com/css2?family=Poppins:ital,wght@0,100;0,200;0,300;0,400;0,500;0,600;0,700;0,800;0,900;1,100;1,200;1,300;1,400;1,500;1,600;1,700;1,800;1,900&display=swap" rel="stylesheet">
<script src="tiket.js"></script>
</head>
<body>
       <!-- header -->
       <header>
        <nav class = "navbar">
          <div class = "container">
            <div class="jotasi">
                <a href = "home.php" class = "navbar-brand"><img src="../asset/jotasi.png" alt=""></a>
            </div>

            <input type="checkbox" id="menu-toggle" class="menu-toggle">
            <label for="menu-toggle" class="menu-button">&#9776; Menu</label>

            <div class = "navbar-nav" id="navbar">
             <a href="home.php">Home</a>
              <a href="tiket.php">Tiket</a>
              <a href="kuliner.php">kuliner</a>
              <a href="blog.php">Blog</a>
              <a href="contactUs.php">Contact</a>
            </div>
          </div>
        </nav>
        <div class = "banner">
          <div class = "container">
            <h1 class = "banner-title">
              <span>Tiket Wisata</span> Yogyakarta
            </h1>
          </div>
        </div>
      </header>
      <!-- end of header -->
      <div class="tiket-heading">
          <span>Wisata Populer Yogyakarta</span>
          <h3>Rekomendasi Pembelian Tiket</h3>
      </div>

    <section id="tiket">
            <!-- tiket loop -->
            <!-- Your HTML structure -->
            <?php include 'tiket_p.php'; ?>
            <?php if ($result->num_rows > 0) : ?>
                <?php while ($row = $result->fetch_assoc()) : ?>
                        <div class="ticket-container">
                            <div class="ticket-image">
                                <img src = "../asset/<?php echo $row ["gambar"]; ?>" alt = "">
                            </div>
                            <div class="ticket-details">
                                <h3><?php echo $row["tiket_name"]; ?></h3>
                                <p class="price"><?php echo $row["tiket_price"]; ?></p>
                                <p class="desc"><?php echo $row["tiket_desc"]; ?></p>
                                <!-- <div class="quantity">
                                    <label for="ticketQuantity">Jumlah Tiket:</label>
                                    <input type="number" id="ticketQuantity" name="ticketQuantity" min="1" value="1">
                                </div> -->
                                <button class="buy-button mt-2" onclick="addToCart('<?php echo $row["tiket_name"]; ?>', <?php echo $row["tiket_price"]; ?>, '<?php echo $row["gambar"]; ?>', '<?php echo $row["tiket_desc"]; ?>')">Beli Tiket</button>
                            </div>
                        </div>
                <?php endwhile; ?>
            <?php else : ?>
                <p>No results found.</p>
            <?php endif; ?>
    </section>

    <!-- Floating cart container -->
    <div id="cartBtn" class="cart-container">
      <i class='bx bx-cart-add' ></i>  Keranjang: <span id="cartCount">0</span>
    </div>
       
      <!-- footer -->
      <footer>
        <div class = "social-links">
          <a href = "#"><i class = "fab fa-facebook-f"></i></a>
          <a href = "#"><i class = "fab fa-twitter"></i></a>
          <a href = "#"><i class = "fab fa-instagram"></i></a>
          <a href = "#"><i class = "fab fa-pinterest"></i></a>
        </div>
        <span>&copy; 2023 Jogja Wisata Eksplorasi</span>
      </footer>
      <!-- end of footer -->
    
</body>
</html>

<?php mysqli_close($conn); ?>