
document.addEventListener('DOMContentLoaded', function () {
  var menuToggle = document.getElementById('menu-toggle');
  var navbarNav = document.getElementById('navbar');
  var jotasiImage = document.querySelector('.jotasi img');

  menuToggle.addEventListener('change', function () {
    if (menuToggle.checked) {
      navbarNav.classList.add('active');
    } else {
      navbarNav.classList.remove('active');
    }
  });

  window.addEventListener('resize', function () {
    if (window.innerWidth <= 767) {
      jotasiImage.style.display = 'none'; // Sembunyikan gambar jotasi pada layar kecil
    } else {
      jotasiImage.style.display = 'block'; // Tampilkan gambar jotasi pada layar besar
    }
  });
});

var totalHarga = localStorage.getItem("totalHarga") ?? 0;

document.addEventListener("DOMContentLoaded", function () {
  document.getElementById("jumlah").value = totalHarga;
  document.getElementById("bayarButton").onclick = function () {
    localStorage.removeItem("cart");
    localStorage.removeItem("itemQty");
    localStorage.removeItem("totalHarga");

    location.href = "/expo/landing_page/php/tiket.php";
  };
});
