<?php
include "koneksi.php";
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <link rel="stylesheet" href="../style/register.css">
    <title>Registrasi Akun</title>
</head>
<body>
    <div class="container">
        <div class="card-container">
            <div class="left">
                <div class="left-container">
                    <img src="../asset/login.png" alt="">
                </div>
            </div>
            <div class="right">
                <div class="right-container">
                    <form action="regis_p.php" method="post">
                        <h2 class="lg-view">REGISTER NOW</h2>
                        <input type="text" name="username" required placeholder="enter username" class="box">
                        <input type="email" name="email" required placeholder="enter email" class="box">
                        <input type="password" name="password" required placeholder="enter password" class="box">
                        <input type="password" name="cpassword" required placeholder="confirm password" class="box">
                        <button type="submit" name="submit" class="btn" value="login now">Register</button>
                        <p>Have an Account? <a href="login.php">Login Now</a></p>
                    </form>
                </div>
            </div>
        </div>
    </div>
</body>
</html>

<?php mysqli_close($conn); ?>