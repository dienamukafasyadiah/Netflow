document.addEventListener('DOMContentLoaded', function () {
  var menuToggle = document.getElementById('menu-toggle');
  var navbarNav = document.getElementById('navbar');
  var jotasiImage = document.querySelector('.jotasi img');

  menuToggle.addEventListener('change', function () {
    if (menuToggle.checked) {
      navbarNav.classList.add('active');
    } else {
      navbarNav.classList.remove('active');
    }
  });

  window.addEventListener('resize', function () {
    if (window.innerWidth <= 767) {
      jotasiImage.style.display = 'none'; // Sembunyikan gambar jotasi pada layar kecil
    } else {
      jotasiImage.style.display = 'block'; // Tampilkan gambar jotasi pada layar besar
    }
  });
});

let cartItems = [];
document.addEventListener("DOMContentLoaded", function () {
  displayCart();
  document.getElementById("buyButton").onclick = function () {
    location.href = "/expo/landing_page/php/paymet.php";
  };
});

// Function to display cart items
function displayCart() {
  let cart = JSON.parse(localStorage.getItem("cart")) || [];
  let totalHarga = 0; // Add variable to store total price
  let itemQty = 0;

  // Select the HTML element to display cart items
  let cartList = document.getElementById("cartList");
  cartList.innerHTML = ""; // Clear previous content

  if (cart.length === 0) {
    cartList.innerHTML = "<p>No items in the cart.</p>";
  } else {
    cart.forEach(function (item, index) {
      // Create HTML elements for each cart item
      // make cart-item
      let cartItem = document.createElement("div");
      cartItem.classList.add("cart-item");

      // make col-2
      let colImg = document.createElement("div");
      colImg.classList.add("col-2");
      cartItem.appendChild(colImg);

      // make img inside col-2
      let gambar = document.createElement("img");
      gambar.classList.add("img-item");
      gambar.src = "../asset/" + item.gambar;
      colImg.appendChild(gambar);

      // make col-8
      let colContent = document.createElement("div");
      colContent.classList.add("col-8");
      cartItem.appendChild(colContent);

      let itemName = document.createElement("h5");
      itemName.textContent = item.name;
      colContent.appendChild(itemName);

      let itemPrice = document.createElement("h4");
      itemPrice.textContent = "Rp." + item.price;
      colContent.appendChild(itemPrice);

      let itemDesc = document.createElement("p");
      itemDesc.textContent = item.desc;
      colContent.appendChild(itemDesc);

      // make col-2
      let colAction = document.createElement("div");
      colAction.classList.add("col-2");
      cartItem.appendChild(colAction);
      let rowAction = document.createElement("div");
      rowAction.classList.add("row");
      colAction.appendChild(rowAction);

      let itemQuantity = document.createElement("input");
      itemQuantity.classList.add("input-item");
      itemQuantity.type = "number";
      itemQuantity.value = item.quantity || 1;
      itemQuantity.min = 1;
      itemQuantity.addEventListener("change", function () {
        // Update the quantity in the cart when changed
        cart[index].quantity = parseInt(itemQuantity.value);
        localStorage.setItem("cart", JSON.stringify(cart));
        displayCart(); // Update the displayed cart items
      });

      let deleteButton = document.createElement("button");
      deleteButton.textContent = "Delete";
      deleteButton.classList.add("delete-button");
      deleteButton.addEventListener("click", function () {
        // Remove item from the cart when delete button is clicked
        cart.splice(index, 1);
        localStorage.setItem("cart", JSON.stringify(cart));
        displayCart(); // Update the displayed cart items
        updateCartCount(); // Update the cart count after deleting an item
      });

      rowAction.appendChild(itemQuantity);
      rowAction.appendChild(deleteButton);

      // Append cartItem to cartList
      cartList.appendChild(cartItem);

      // Calculate total price for each item and add to totalHarga
      let subtotal = item.price * item.quantity;
      totalHarga += subtotal;
      itemQty += item.quantity;
    });

    localStorage.setItem("itemQty", itemQty);
    localStorage.setItem("totalHarga", totalHarga.toFixed(2));
    // Add an element to display the total price
    let totalHargaElement = document.createElement("p");
    totalHargaElement.textContent = "Total Harga: Rp." + totalHarga.toFixed(2);
    cartList.appendChild(totalHargaElement);
  }

}
