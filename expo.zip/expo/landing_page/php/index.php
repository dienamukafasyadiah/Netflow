<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <link rel="stylesheet" href="../style/pralogin.css">
    <title>Halaman Masuk</title>
</head>
<body>
    <!-- header -->
    <header>
        <nav>
            <h1 class="logo">
                <a href="/">JOTASI</a>
            </h1>
            <a href="regis.php" class="btn-sign-up">Sign Up</a>
        </nav>
        <div class="header-title">Yogyakarta</div>
    </header>
    <!-- about -->
    <section id="about">
        <div class="about-container">
            <div class="image-gallery">
                <div class="image-box">
                    <img src="../asset/pralogin1.jpg" alt="image">
                    <h2 class="yogya">J</h2>
                </div>
                <div class="image-box">
                    <img src="../asset/pralogin2.jpg" alt="image">
                    <h2 class="yogya">o</h2>
                </div>
                <div class="image-box">
                    <img src="../asset/pralogin3.jpeg" alt="image">
                    <h2 class="yogya">g</h2>
                </div>
                <div class="image-box">
                    <img src="../asset/pralogin4.jpg" alt="image">
                    <h2 class="yogya">Y</h2>
                </div>
                <div class="image-box">
                    <img src="../asset/pralogin5.jpg" alt="image">
                    <h2 class="yogya">a</h2>
                </div>
            </div>
            <div class="about-info">
            Bagi Anda yang ingin mengeksplorasi Jogja secara mendalam, kami hadirkan Jogja Wisata Eksplorasi. Website ini akan memberikan informasi lengkap tentang berbagai macam tempat wisata di Jogja, mulai dari lokasi, kuliner, hingga tips berkunjung.
            </div>
        </div>
    </section>

    <!-- footer -->
    <footer>
        Jogja Wisata Eksplorasi
    </footer>
</body>
</html>