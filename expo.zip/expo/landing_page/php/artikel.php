<?php 
include "koneksi.php"
?>

<!DOCTYPE html>
<html lang="en">
  <head>
    <meta charset="UTF-8" />
    <meta name="viewport" content="width=device-width, initial-scale=1.0" />
    <link rel="stylesheet" href="../style/artikel.css" />
    <link href="https://unpkg.com/boxicons@2.1.4/css/boxicons.min.css" rel="stylesheet" />
    <title>Artikel</title>
  </head>
  <body>
    <div class="nav">
      <ul>
        <li><a href="home.php">Home</a></li>
        <li><a href="tiket.php">Tiket</a></li>
        <li><a href="#gallery">Kuliner</a></li>
        <li><a href="#blog">Blog</a></li>
        <li><a href="contactUs.php">Contact</a></li>
      </ul>
    </div>
    <div class="container">
      <div class="header">
        <h2>Wisata Terbaru di Yogyakarta Paling Instagramable</h2>
        <p>
          Kota Yogyakarta seakan tak pernah kehabisan tempat baru untuk dieksplorasi. Apalagi makin ke sini makin banyak pula tempat seru yang estetik dan Instagramable, asyik jadi jujugan liburan. Selain konsep tempatnya yang unik, lanskap
          yang ditawarkan juga gak main-main indahnya. Ada yang view-nya langsung ke persawahan, pantai, laut, bahkan pemandangan kota dari atas. Kalau kamu ingin tahu destinasi kekinian di Yogyakarta terbaru yang Instagramable, simak
          beberapa daftarnya berikut ini. Jangan lupa bawa kamera terbaikmu kalau ke sini, ya!
        </p><br/>
        <div class="gambar"></div><br/>
        <h2>Berikut Destinasi kekinian di Yogyakarta yang Instagramable</h2>
        <hr/>
      </div>
      
      <div class="main">
          <?php
          $result = mysqli_query($conn, "SELECT * FROM artikel");
          while($row = mysqli_fetch_array($result, MYSQLI_ASSOC))
          {
          ?>
          <div class="paragraf">
                  <h3><?php echo $row ["judul"]; ?></h3>
                  <p><?php echo $row ["isi"]; ?> </p>
                  <div class="gambarAR" >
                  <img src="../asset/<?php echo $row ["image"]; ?>" alt="">
                  </div>
                  <p><?php echo $row ["deskripsi"]; ?> </p>
          </div>
          <?php
          }
          ?>
       </div>
    </div>
    <footer id="contact">
      <div class="layar-dalam">
        <div>
          <img src="asset/JOTASI.png" alt="" /><br />
          <i class="bx bxl-instagram"></i>
          <i class="bx bxl-facebook-circle"></i>
          <i class="bx bxl-twitter"></i>
          <i class="bx bxl-youtube"></i>
          <i class="bx bxl-tiktok"></i>
        </div>
        <div class="dropdown">
          <h4>Kunjungi Situs Lainnya</h4>
          <select name="situs" id="situs">
            <option value="pilih">Pilih Situs</option>
            <option value="Event">Event</option>
            <option value="Kuliner">Kuliner</option>
            <option value="Blog">Blog Yogyakarta</option>
            <option value="creative">Creative</option></select
          ><br />
        </div>
      </div>
      <div class="layar-dalam">
        <div class="copyright">&copy; 2023 Jogja Wisata Eksplorasi</div>
      </div>
    </footer>
  </body>
</html>

<?php mysqli_close($conn); ?>


