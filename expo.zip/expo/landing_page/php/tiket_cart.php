<?php
include "koneksi.php";
?>


<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0, maximum-scale=1.0, user0scalable=no">
    <title>Cart Tiket</title>
    <link rel="stylesheet" href="../style/tiketcart.css">
    <link rel="preconnect" href="https://fonts.googleapis.com">
    <link href='https://unpkg.com/boxicons@2.1.4/css/boxicons.min.css' rel='stylesheet'>
<link rel="preconnect" href="https://fonts.gstatic.com" crossorigin>
<link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/5.15.1/css/all.min.css" integrity="sha512-+4zCK9k+qNFUR5X+cKL9EIR+ZOhtIloNl9GIKS57V1MyNsYpYcUrUeQc9vNfzsWfV28IaLL3i96P9sdNyeRssA==" crossorigin="anonymous" />
<link href="https://fonts.googleapis.com/css2?family=Poppins:ital,wght@0,100;0,200;0,300;0,400;0,500;0,600;0,700;0,800;0,900;1,100;1,200;1,300;1,400;1,500;1,600;1,700;1,800;1,900&display=swap" rel="stylesheet">
<script src="tiket_cart.js"></script>
</head>
<body>
       <!-- header -->
       <header>
        <nav class = "navbar">
          <div class = "container">
            <div class="jotasi">
                <a href = "home.php" class = "navbar-brand"><img src="../asset/jotasi.png" alt=""></a>
            </div>

            <input type="checkbox" id="menu-toggle" class="menu-toggle">
            <label for="menu-toggle" class="menu-button">&#9776; Menu</label>

            <div class = "navbar-nav" id="navbar">
              <a href="home.php">Home</a>
              <a href="tiket.php">Tiket</a>
              <a href="kuliner.php">kuliner</a>
              <a href="blog.php">Blog</a>
              <a href="contactUs.php">Contact</a>
            </div>
          </div>
        </nav>

      </header>
      <!-- end of header -->
     
      <section id="cartSection">
          <div class="cart-header">
              <h2>Tiket Wisata Jotasi</h2>
              <p>lanjutkan pembayaran untuk membeli Tiket</p>
          </div>
          <div class="container-tiket">
              <!-- Display cart items -->
              <!-- <div id="" class="cart-list">
                <div class="cart-item">
                  <div class="col-2">
                    <img class="img-item" src="../asset/tiket6.jpg" />
                  </div>
                  <div class="col-8">
                    <h3>Nama Tiket</h3>
                    <h4>Price</h4>
                    <p>Desc</p>
                  </div>
                  <div class="col-2">
                    <div id="row_action" class="row">
                      <input id="" type="number" class="input-item">
                      </input>
                      <button class="delete-button">
                        Delete
                      </button>
                    </div>
                  </div>
                </div> -->

              <div id="cartList" class="cart-list">
                  <!-- Cart items will be displayed here -->
              </div>
              <a class="back" href="tiket.php"><i class='bx bx-subdirectory-left'></i>  Back</a>
              <button class="buy" id="buyButton"><i class='bx bx-dollar-circle'></i>  Beli Sekarang</button>
              <!-- Additional elements or content can be added here -->
          </div>
      </section>


       
      <!-- footer -->
      <footer>
        <div class = "social-links">
          <a href = "#"><i class = "fab fa-facebook-f"></i></a>
          <a href = "#"><i class = "fab fa-twitter"></i></a>
          <a href = "#"><i class = "fab fa-instagram"></i></a>
          <a href = "#"><i class = "fab fa-pinterest"></i></a>
        </div>
        <span>&copy; 2023 Jogja Wisata Eksplorasi</span>
      </footer>
      <!-- end of footer -->
      
    
</body>
</html>

<?php mysqli_close($conn); ?>