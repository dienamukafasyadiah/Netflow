<?php
include "koneksi.php";
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/5.15.1/css/all.min.css" integrity="sha512-+4zCK9k+qNFUR5X+cKL9EIR+ZOhtIloNl9GIKS57V1MyNsYpYcUrUeQc9vNfzsWfV28IaLL3i96P9sdNyeRssA==" crossorigin="anonymous" />
    <link rel="stylesheet" href="../style/blog.css">
    <title>Blog JOTASI</title>
</head>
<body>
    
      <!-- header -->
      <header>
        <nav class = "navbar">
          <div class = "container">
            <div class="jotasi">
                <a href = "index.html" class = "navbar-brand"><img src="../asset/jotasi.png" alt=""></a>
            </div>
            <input type="checkbox" id="menu-toggle" class="menu-toggle">
            <label for="menu-toggle" class="menu-button">&#9776; Menu</label>
            <div class = "navbar-nav" id="navbar">
              <a href="home.php">Home</a>
              <a href="tiket.php">Tiket</a>
              <a href="kuliner.php">kuliner</a>
              <a href="blog.php">Blog</a>
              <a href="contactUs.php">Contact</a>
            </div>
          </div>
        </nav>
        <div class = "banner">
          <div class = "container">
            <h1 class = "banner-title">
              <span>Blog</span> Yogyakarta
            </h1>
          </div>
        </div>
      </header>
      <!-- end of header -->

      <!-- aritikel blog -->
      <section id="blog">
        <div class="container-blog">
            <div class="main">
              <h2>Wisata Terbaru di Yogyakarta Paling Instagramable</h2><br/>
            <?php
                $result = mysqli_query($conn, "SELECT * FROM artikel");
                while($row = mysqli_fetch_array($result, MYSQLI_ASSOC))
                {
                ?>
                <div class="paragraf">
                        <h3><?php echo $row ["judul"]; ?></h3>
                        <p><?php echo $row ["informasi"]; ?> </p>
                        <div class="gambarAR" >
                        <img src="../asset/<?php echo $row ["gambar"]; ?>" alt="">
                        </div>
                        <p><?php echo $row ["deskripsi"]; ?> </p>
                </div>
                <?php
                }
                ?>
            </div>
        </div>
      </section>

        <!-- footer -->
    <footer>
        <div class = "social-links">
          <a href = "#"><i class = "fab fa-facebook-f"></i></a>
          <a href = "#"><i class = "fab fa-twitter"></i></a>
          <a href = "#"><i class = "fab fa-instagram"></i></a>
          <a href = "#"><i class = "fab fa-pinterest"></i></a>
        </div>
        <span>&copy; 2023 Jogja Wisata Eksplorasi</span>
      </footer>
      <!-- end of footer -->
      <script>
          document.addEventListener('DOMContentLoaded', function () {
            var menuToggle = document.getElementById('menu-toggle');
            var navbarNav = document.getElementById('navbar');
            var jotasiImage = document.querySelector('.jotasi img');

            menuToggle.addEventListener('change', function () {
              if (menuToggle.checked) {
                navbarNav.classList.add('active');
              } else {
                navbarNav.classList.remove('active');
              }
            });

            window.addEventListener('resize', function () {
              if (window.innerWidth <= 767) {
                jotasiImage.style.display = 'none'; // Sembunyikan gambar jotasi pada layar kecil
              } else {
                jotasiImage.style.display = 'block'; // Tampilkan gambar jotasi pada layar besar
              }
            });
          });
        </script>

</body>
</html>

<?php mysqli_close($conn); ?>