<?php
include "koneksi.php";
?>

<!DOCTYPE html>
<html>
  <head>
    <meta charset="utf-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <title>Art.Design Blog</title>
    <meta name="viewport" content="width=device-width, initial-scale=1">
    <!-- icon -->
    <link href='https://unpkg.com/boxicons@2.1.4/css/boxicons.min.css' rel='stylesheet'>
    <!-- Font awesome icon -->
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/5.15.1/css/all.min.css" integrity="sha512-+4zCK9k+qNFUR5X+cKL9EIR+ZOhtIloNl9GIKS57V1MyNsYpYcUrUeQc9vNfzsWfV28IaLL3i96P9sdNyeRssA==" crossorigin="anonymous" />
    <link rel="stylesheet" href="../style/home.css">
  </head>
  <body>

    <!-- header -->
    <header>
      <nav class = "navbar">
        <div class = "container">
          <a href = "index.html" class = "navbar-brand"><img src="../asset/jotasi.png" alt=""></a>
          <div class = "navbar-nav">
            <a href="home.php">Home</a>
            <a href="tiket.php">Tiket</a>
            <a href="kuliner.php">kuliner</a>
            <a href="blog.php">Blog</a>
            <a href="contactUs.php">Contact</a>
            <a href="index.php"><i class='bx bx-log-out'></i>Logout</a>
          </div>
        </div>
      </nav>
      <div class = "banner">
        <div class = "container">
          <h1 class = "banner-title">
            <span>Kota Istimewa</span>Yogyakarta
          </h1>
          <p>  Jogja, kota yang menyimpan sejuta pesona. Kota ini selalu menawarkan
            pengalaman baru bagi setiap pengunjungnya.</p>
          <form>
            <input type = "text" class = "search-input" placeholder="Tentukan Tujuan mu">
            <button type = "submit" class = "search-btn">
              <i class = "fas fa-search"></i>
            </button>
          </form>
        </div>
      </div>
    </header>
    <!-- end of header -->

    <!-- foto-foto -->
    <section id="wisata">
          <div><img src="../asset/wisata1.jpg" /></div>
          <div><img src="../asset/wisata2.jpg" /></div>
          <div><img src="../asset/wisata3.jpg" /></div>
          <div><img src="../asset/wisata4.jpg" /></div>
          <div><img src="../asset/wisata5.png" /></div>
          <div><img src="../asset/wisata6.jpg" /></div>
          <div><img src="../asset/wisata7.jpg" /></div>
          <div><img src="../asset/wisata8.jpg" /></div>
    </section>
    
  

    <!-- spot foto -->
    <section class = "design" id = "design">
      <div class = "container">
        <div class = "title">
          <h2>Inspirasi Perjalanan</h2>
          <p>Jogja, kota yang kaya akan sejarah dan budaya, selalu menawarkan pesona yang baru untuk dijelajahi."</p>
        </div>

        <div class = "design-content">
          <!-- item -->
          <?php
                  $result = mysqli_query($conn, "SELECT * FROM media");
                  while($row = mysqli_fetch_array($result, MYSQLI_ASSOC))
                  {
                  ?>
          <div class = "design-item">
            <div class = "design-img">
              <img src = "../asset/<?php echo $row ["image_media"]; ?>" alt = "">
              <span><i class = "far fa-heart"></i> 22</span>
              <span>JOTASI</span>
            </div>
            <div class = "design-title">
              <a href = "artikel.php"><?php echo $row ["judul_media"]; ?></a>
            </div>
          </div>
          <!-- end of item -->
          <?php
                  }
                  ?>
        </div>
      </div>
    </section>
    <!-- end of design -->


    <!-- blog -->
    <section class = "blog" id = "blog">
      <div class = "container">
        <div class = "title">
          <h2>Blog Yogyakarta</h2>
          <p>Yogyakarta, kota yang penuh sejarah dan budaya. Temukan informasi dan cerita menarik tentang kota ini di blog kami.</p>
        </div>
        <div class = "blog-content">
        <?php
                  $result = mysqli_query($conn, "SELECT * FROM blog");
                  while($row = mysqli_fetch_array($result, MYSQLI_ASSOC))
                  {
                  ?>
          <!-- item -->
          <div class = "blog-item">
            <div class = "blog-gambar">
              <img src = "../asset/<?php echo $row ["image_blog"]; ?>" alt = "">
              <span><i class = "far fa-heart"></i></span>
            </div>
            <div class = "blog-text">
              <span><?php echo $row ["tanggal"]; ?></span>
              <h2><?php echo $row ["judul_blog"]; ?></h2>
              <p><?php echo $row ["deskripsi_blog"]; ?></p>
              <a href = "blog.php">Read More</a>
            </div>
          </div>
          <?php
                  }
                  ?>
          <!-- end of item -->
        </div>
      </div>
    </section>
    <!-- end of blog -->

    <!-- kuliner jogja -->
    <section id="kuliner">
          <div class="layar-kuliner">
              <h2>Kuliner Yogyakarta</h2>
              <p>"Temukan pengalaman kuliner di Yogyakarta yang tak terlupakan di sini!"</p>
          </div>
          
          <div class="container-kuliner">
          <?php
                  $result = mysqli_query($conn, "SELECT * FROM kuliner");
                  while($row = mysqli_fetch_array($result, MYSQLI_ASSOC))
                  {
                  ?>
              <div class="layar">
                    <div class="kuliner-box">
                        <div class="gambar-kuliner">
                            <img src="../asset/<?php echo $row ["gambar"]; ?>" alt="">
                        </div>
                        <div class="kuliner-text">
                            <h4><?php echo $row ["judul"]; ?></h4>
                            <p><?php echo $row ["deskripsi"]; ?></p>
                            <a href="kuliner.php">Read More</a>
                        </div>
                    </div>
              </div>
              <?php
                  }
                  ?>
          </div>
      </section>
    <!-- end of kuliner jogja -->

    <!-- about -->
    <section class = "about" id = "about">
      <div class = "container">
        <div class = "about-content">
          <div>
            <img src = "../asset/tentangkami.jpg" alt = "">
          </div>
          <div class = "about-text">
            <div class = "title">
              <h2>Tentang Kami</h2>
              <p>"Jogja Wisata Eksplorasi"</p>
            </div>
            <p>Jogja Wisata Eksplorasi adalah sebuah website yang menyajikan informasi wisata di Yogyakarta. Website ini didirikan oleh sekelompok Mahasiswa yang memiliki passion di bidang pariwisata. Kami ingin membantu wisatawan untuk menemukan tempat-tempat wisata yang menarik di Yogyakarta. </p>
            <p>JOTASI menyajikan berbagai informasi tentang wisata di Yogyakarta, mulai dari tempat wisata alam, tempat wisata budaya, hingga tempat wisata kuliner. Kami berharap website Jogja Wisata Eksplorasi dapat menjadi sumber informasi yang bermanfaat bagi wisatawan yang ingin berkunjung ke Yogyakarta.</p>
          </div>
        </div>
      </div>
    </section>
    <!-- end of about -->

    <!-- footer -->
    <footer>
      <div class = "social-links">
        <a href = "#"><i class = "fab fa-facebook-f"></i></a>
        <a href = "#"><i class = "fab fa-twitter"></i></a>
        <a href = "#"><i class = "fab fa-instagram"></i></a>
        <a href = "#"><i class = "fab fa-pinterest"></i></a>
      </div>
      <span>&copy; 2023 Jogja Wisata Eksplorasi</span>
    </footer>
    <!-- end of footer -->
    
    
  </body>
</html>

<?php mysqli_close($conn); ?>