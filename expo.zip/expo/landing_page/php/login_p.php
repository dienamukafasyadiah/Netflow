<?php
include "koneksi.php";

$email = $_POST['email'];
$password = $_POST['password'];
$password = md5($password);

$query_sql = "SELECT * FROM register WHERE email = '$email' AND password = '$password' ";
$hasil = mysqli_query($conn, $query_sql);

if(mysqli_num_rows($hasil) > 0){
    header("location: ../php/home.php");
} else{
    echo "Register Gagal: " . mysqli_error($conn);
}

?>

