<?php
include "koneksi.php";

// Query to select data from the tiket table
$sql = "SELECT tiket_name, tiket_desc, gambar, tiket_price FROM tiket";
$result = $conn->query($sql);

?>

