<?php
// Sertakan file koneksi ke database
include "koneksi.php"; // Pastikan file ini mengandung informasi koneksi ke database

// Tangkap data dari formulir
if (isset($_GET['id'])) {
    $reviewId = mysqli_real_escape_string($conn, $_GET['id']);

    // Lakukan operasi delete sesuai dengan $reviewId

    // Contoh query delete
    $query = "DELETE FROM review_kuliner WHERE id = '$reviewId'";
    $result = mysqli_query($conn, $query);

    // Periksa apakah query berhasil dijalankan
    if ($result) {
        echo "Review berhasil dihapus.";
        
        // Redirect ke halaman tertentu setelah delete berhasil
        header("Location: kuliner.php");
        exit(); // Pastikan untuk keluar setelah melakukan redirect
    } else {
        echo "Terjadi kesalahan: " . mysqli_error($conn);
    }
} else {
    echo "ID review tidak valid.";
}

// Tutup koneksi ke database
mysqli_close($conn);
?>
