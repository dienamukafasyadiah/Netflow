<?php
include "koneksi.php";
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <link rel="stylesheet" href="../style/register.css">
    <title>Login Akun</title>
</head>
<body>
    <div class="container">
        <div class="card-container">
            <div class="left">
                <div class="left-container">
                    <img src="../asset/login.png" alt="">
                </div>
            </div>
            <div class="right">
                <div class="right-container">
                    <form action="login_p.php" method="post">
                        <h2 class="lg-view">LOGIN NOW</h2>
                        <h2 class="sm-view">LOGIN NOW</h2>
                        <input type="text" name="email" required placeholder="Enter Email">
                        <input type="password" name="password" required placeholder="enter password" >
                        <button type="submit" name="submit" class="btn" value="login now">Login</button>
                        <p>Don't Have an Account? <a href="regis.php">Register Now</a></p>
                    </form>
                </div>
            </div>
        </div>
    </div>
</body>
</html>

<?php mysqli_close($conn); ?>