<?php
include "koneksi.php";
?>


<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0, maximum-scale=1.0, user0scalable=no">
    <title>Cart Tiket</title>
    <link rel="stylesheet" href="../style/paymet.css">
    <link rel="preconnect" href="https://fonts.googleapis.com">
    <link href='https://unpkg.com/boxicons@2.1.4/css/boxicons.min.css' rel='stylesheet'>
  <link rel="preconnect" href="https://fonts.gstatic.com" crossorigin>
  <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/5.15.1/css/all.min.css" integrity="sha512-+4zCK9k+qNFUR5X+cKL9EIR+ZOhtIloNl9GIKS57V1MyNsYpYcUrUeQc9vNfzsWfV28IaLL3i96P9sdNyeRssA==" crossorigin="anonymous" />
  <link href="https://fonts.googleapis.com/css2?family=Poppins:ital,wght@0,100;0,200;0,300;0,400;0,500;0,600;0,700;0,800;0,900;1,100;1,200;1,300;1,400;1,500;1,600;1,700;1,800;1,900&display=swap" rel="stylesheet">
  <script src="paymet.js"></script>
</head>
<body>
       <!-- header -->
       <header>
        <nav class = "navbar">
          <div class = "container">
            <div class="jotasi">
                <a href = "index.html" class = "navbar-brand"><img src="../asset/jotasi.png" alt=""></a>
            </div>

            <input type="checkbox" id="menu-toggle" class="menu-toggle">
            <label for="menu-toggle" class="menu-button">&#9776; Menu</label>

            <div class = "navbar-nav" id="navbar">
              <a href="home.php">Home</a>
              <a href="tiket.php">Tiket</a>
              <a href="kuliner.php">kuliner</a>
              <a href="blog.php">Blog</a>
              <a href="contactUs.php">Contact</a>
            </div>
          </div>
        </nav>

      </header>
      <!-- end of header -->
      
      <!-- form transaksi -->
     
      <div class="container-paymet">
        <h1>Pembayaran Transaksi</h1>
        <form action="" onsubmit="return false;">
          <!-- Menggunakan onsubmit="return false;" untuk mencegah formulir dikirim secara default -->
          
          <label for="nama"><p>Nama Lengkap</p></label>
          <input type="text" id="nama" name="nama" required>

          <label for="nomor-rekening">Nomor Rekening</label>
          <input type="text" id="nomor-rekening" name="nomor-rekening" required>

          <label for="bank">Bank</label>
          <select name="bank" id="bank">
            <option value="bca">BCA</option>
            <option value="bri">BRI</option>
            <option value="mandiri">Mandiri</option>
            <option value="dana">Dana</option>
            <option value="gopay">Gopay</option>
          </select>

          <label for="jumlah">Jumlah Pembayaran</label>
          <input type="number" id="jumlah" name="jumlah" required>

          <!-- Tambahkan elemen span untuk menampilkan pesan kesalahan -->
          <span id="error-message" style="color: red;"></span>

          <!-- Ganti onclick dengan event listener untuk memanggil fungsi bayar() -->
          <button type="button" id="bayarButton">Bayar Sekarang</button>
        </form>
      </div>
      


       
      <!-- footer -->
      <footer>
        <div class = "social-links">
          <a href = "#"><i class = "fab fa-facebook-f"></i></a>
          <a href = "#"><i class = "fab fa-twitter"></i></a>
          <a href = "#"><i class = "fab fa-instagram"></i></a>
          <a href = "#"><i class = "fab fa-pinterest"></i></a>
        </div>
        <span>&copy; 2023 Jogja Wisata Eksplorasi</span>
      </footer>
      <!-- end of footer -->
    
</body>
</html>

<?php mysqli_close($conn); ?>