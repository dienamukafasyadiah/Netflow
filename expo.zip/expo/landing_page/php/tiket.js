document.addEventListener('DOMContentLoaded', function () {
  var menuToggle = document.getElementById('menu-toggle');
  var navbarNav = document.getElementById('navbar');
  var jotasiImage = document.querySelector('.jotasi img');

  menuToggle.addEventListener('change', function () {
    if (menuToggle.checked) {
      navbarNav.classList.add('active');
    } else {
      navbarNav.classList.remove('active');
    }
  });

  window.addEventListener('resize', function () {
    if (window.innerWidth <= 767) {
      jotasiImage.style.display = 'none'; // Sembunyikan gambar jotasi pada layar kecil
    } else {
      jotasiImage.style.display = 'block'; // Tampilkan gambar jotasi pada layar besar
    }
  });
});

let cartItems = [];
let itemQty = localStorage.getItem("itemQty") ?? "0";
let cartCount = parseInt(itemQty);

document.addEventListener("DOMContentLoaded", function () {
  updateCartCount();

  document.getElementById("cartBtn").onclick = function () {
    location.href = "/expo/landing_page/php/tiket_cart.php";
    // Your code here
    // This function will be executed when the element with ID "cartCount" is clicked
  };
});

// JavaScript function to add tickets to the cart
function addToCart(ticketName, ticketPrice, ticketImage, ticketDesc) {
  // Create or retrieve the cart array from local storage
  let cart = JSON.parse(localStorage.getItem("cart")) || [];

  // Check if the ticket is already in the cart
  let existingItem = cart.find((item) => item.name === ticketName);

  if (existingItem) {
    existingItem.quantity += 1; // If the ticket is already in the cart, increment the quantity
  } else {
    // If the ticket is not in the cart, add it to the cart with quantity 1
    cart.push({
      name: ticketName,
      price: ticketPrice,
      gambar: ticketImage,
      desc: ticketDesc,
      quantity: 1,
    });
  }

  // Save the updated cart back to local storage
  localStorage.setItem("cart", JSON.stringify(cart));

  // Alert to show the ticket has been added to the cart (you can customize this)
  // alert("Ticket added to cart!");
  cartCount++;
  updateCartCount();
}

// JavaScript function to update cart count and display in the floating cart
function updateCartCount() {
  localStorage.setItem("itemQty", cartCount);

  // Display the cart count in the floating cart container
  document.getElementById("cartCount").innerText = cartCount;
}
