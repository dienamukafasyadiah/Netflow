<?php
// Sertakan file koneksi ke database
include "koneksi.php"; // Pastikan file ini mengandung informasi koneksi ke database

// Cek apakah data yang diterima dari formulir sesuai
if (isset($_POST['userName'], $_POST['userReview'])) {
    // Tangkap data dari formulir
    $userName = mysqli_real_escape_string($conn, $_POST['userName']);
    $userReview = mysqli_real_escape_string($conn, $_POST['userReview']);

    // Query untuk menyimpan data ke dalam tabel review_kuliner
    $query = "INSERT INTO review_kuliner (userName, userReview) VALUES ('$userName', '$userReview')";

    // Jalankan query
    $result = mysqli_query($conn, $query);
    
    if ($result) {
        // Redirect ke halaman tertentu setelah review berhasil disimpan
        header("Location: kuliner.php");
        exit(); // Pastikan untuk keluar setelah melakukan redirect
    } else {
        echo "Terjadi kesalahan: " . mysqli_error($conn);
    }
} else {
    echo "Data review tidak lengkap.";
}

// Tutup koneksi ke database
mysqli_close($conn);
?>
