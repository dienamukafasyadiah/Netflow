<?php
include "koneksi.php";

$username = $_POST['username'];
$email = $_POST['email'];
$password = $_POST['password'];
$password = md5($password);

$query_sql = "INSERT INTO register (username, email, password)
            VALUES('$username','$email', '$password')";

if(mysqli_query($conn, $query_sql)){
    header("location: login.php");
} else{
    echo "Register Gagal: " . mysqli_error($conn);
}

?>

