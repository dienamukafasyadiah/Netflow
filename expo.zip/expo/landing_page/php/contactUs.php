<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <link rel="stylesheet" href="../style/contactUs.css">
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/5.15.1/css/all.min.css" integrity="sha512-+4zCK9k+qNFUR5X+cKL9EIR+ZOhtIloNl9GIKS57V1MyNsYpYcUrUeQc9vNfzsWfV28IaLL3i96P9sdNyeRssA==" crossorigin="anonymous" />
    <title>Contact Us</title>
</head>
<body>
     <!-- header -->
     <header>
     <nav class="navbar">
        <div class="container">
            <div class="jotasi">
                <a href="home.php" class="navbar-brand"><img src="../asset/jotasi.png" alt=""></a>
            </div>

            <input type="checkbox" id="menu-toggle" class="menu-toggle">
            <label for="menu-toggle" class="menu-button">&#9776; Menu</label>

            <div class="navbar-nav" id="navbar">
                <a href="home.php">Home</a>
                <a href="tiket.php">Tiket</a>
                <a href="kuliner.php">kuliner</a>
                <a href="blog.php">Blog</a>
                <a href="contactUs.php">Contact</a>
            </div>
        </div>
    </nav>
        <div class = "banner">
          <div class = "container">
            <h1 class = "banner-title">
              <span>Contact</span> Us
            </h1>
          </div>
        </div>
      </header>

      <!-- content -->
      <section class="content">
        <div class="layar">
          <div class="support">
            <img src="../asset/p2.png" />
            <h6>Contact Us</h6>
            <p>"Kami akan menghubungi Anda sesegera mungkin untuk menanggapi pertanyaan atau permintaan Anda.""</p>
          </div>
          <div class="support">
            <img src="../asset/p1.png" />
            <h6>Hubungi Kami</h6>
            <p>"Kami senang mendengar dari Anda! Jika Anda memiliki pertanyaan, komentar, atau saran, jangan ragu untuk menghubungi kami."</p>
          </div>
          <div class="support">
            <img src="../asset/p3.png" />
            <h6>Isi Formulir</h6>
            <p>"Kami selalu berusaha untuk meningkatkan layanan kami, dan umpan balik Anda sangat berharga bagi kami. Kami akan menghubungi Anda sesegera mungkin untuk menanggapi pertanyaan atau permintaan Anda."</p>
          </div>
        </div>
      </section>

      <!-- form Contact US -->
      <section class="contact">
          <div class="cs">
            <form action="">
              <h2>Hubungi Kami</h2><br/>
              <input type="text" placeholder="Nama"> <br/>
              <input type="email" placeholder="Alamat Email"> <br/>
              <input type="text" placeholder="Wisata"><br/>
              <input type="phone" placeholder="Telepon"><br/>
              <textarea rows="10" placeholder="Pesan"></textarea><br/>
              <button>Kirim</button>
            </form>
          </div>
      </section>

      <!-- closing -->
      <section>
        <div class="closing">
          <h2>Trimakasih</h2><br/>
          <p>Jogja Wisata Eksplorasi senantiasa siap membantu Anda dalam merencanakan perjalanan wisata yang tak terlupakan di Yogyakarta. Jangan ragu untuk menghubungi kami melalui formulir kontak ini atau melalui surel ke Jotasi@Gmail.com</p><br/>
          <p>Kami akan dengan senang hati menjawab pertanyaan Anda mengenai paket wisata kami, memberikan rekomendasi destinasi wisata yang menarik, dan membantu Anda membuat reservasi. Tim kami yang berpengalaman dan berdedikasi akan memastikan bahwa perjalanan Anda di Yogyakarta menjadi pengalaman yang luar biasa.</p>
        </div>
      </section>
      <!-- footer -->
      <footer>
        <div class = "social-links">
          <a href = "#"><i class = "fab fa-facebook-f"></i></a>
          <a href = "#"><i class = "fab fa-twitter"></i></a>
          <a href = "#"><i class = "fab fa-instagram"></i></a>
          <a href = "#"><i class = "fab fa-pinterest"></i></a>
        </div>
        <span>&copy; 2023 Jogja Wisata Eksplorasi</span>
      </footer>

      <script>
        document.addEventListener('DOMContentLoaded', function () {
          var menuToggle = document.getElementById('menu-toggle');
          var navbarNav = document.getElementById('navbar');
          var jotasiImage = document.querySelector('.jotasi img');

          menuToggle.addEventListener('change', function () {
            if (menuToggle.checked) {
              navbarNav.classList.add('active');
            } else {
              navbarNav.classList.remove('active');
            }
          });

          window.addEventListener('resize', function () {
            if (window.innerWidth <= 767) {
              jotasiImage.style.display = 'none'; // Sembunyikan gambar jotasi pada layar kecil
            } else {
              jotasiImage.style.display = 'block'; // Tampilkan gambar jotasi pada layar besar
            }
          });
        });
</script>

</body>
</html>