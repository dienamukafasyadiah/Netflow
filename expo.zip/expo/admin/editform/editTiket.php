<?php
include "../dashadmin/koneksi.php";

    $nama = '';
    $image = '';
    $deskripsi = '';
    $harga =''; 

    if(isset($_GET['update'])){
        $id = $_GET['update'];

        $query = "SELECT * FROM tiket WHERE id ='$id';";
        $sql= mysqli_query($conn, $query);
        $row = mysqli_fetch_array($sql, MYSQLI_ASSOC);
        
        // unlink("../../aset/" . $row['image']);
        
        // $query = "DELETE FROM tiket WHERE id=$id";

        $nama = $row['tiket_name'];
        $image =$row['gambar'];
        $deskripsi =$row ['tiket_desc'];
        $harga =$row['tiket_price']; 
}
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    
    <!----======== CSS ======== -->
    <link rel="stylesheet" href="../style/allEdit.css">
    
    <!----===== Boxicons CSS ===== -->
    <link href='https://unpkg.com/boxicons@2.1.1/css/boxicons.min.css' rel='stylesheet'>

    <title>Admin user</title> 
</head>
<body>
    <nav class="sidebar close">
        <header>
            <div class="image-text">
                <span class="image">
                    <img src="../../landing_page/asset/jotasi.png" alt="">
                </span>

                <div class="text logo-text">
                    <span class="name">JOTASI</span>
                    <span class="profession">Jogja Wisata Eksplorasi</span>
                </div>
            </div>

            <i class='bx bx-chevron-right toggle'></i>
        </header>

        <div class="menu-bar">
            <div class="menu">

            <ul class="menu-links">
                    <li class="nav-link">
                        <a href="../dashadmin/admin.php">
                            <i class='bx bx-home-alt icon' ></i>
                            <span class="text nav-text">Dashboard</span>
                        </a>
                    </li>

                    <li class="nav-link">
                        <a href="../dashadmin/dashblog.php">
                            <i class='bx bxl-blogger'></i>
                            <span class="text nav-text">Blog</span>
                        </a>
                    </li>

                    <li class="nav-link">
                        <a href="../dashadmin/dashkuliner.php">
                            <i class='bx bx-bowl-hot'></i>
                            <span class="text nav-text">Kuliner</span>
                        </a>
                    </li>
                    

                    <li class="nav-link">
                        <a href="../dashadmin/dashmedia.php">
                            <i class='bx bx-video-recording'></i>
                            <span class="text nav-text">Media</span>
                        </a>
                    </li>

                    
                    <li class="nav-link">
                        <a href="../dashadmin/dashtiket.php">
                            <i class='bx bx-money-withdraw'></i>
                            <span class="text nav-text">Tiket</span>
                        </a>
                    </li>

                    <li class="nav-link">
                        <a href="../dashadmin/dashuser.php">
                            <i class='bx bx-user'></i>
                            <span class="text nav-text">user</span>
                        </a>
                    </li>

            </ul>
            
            </div>

            <div class="bottom-content">
                <li class="">
                    <a href="../../landing_page/php/index.php">
                        <i class='bx bx-log-out icon' ></i>
                        <span class="text nav-text">Logout</span>
                    </a>
                </li>
                
            </div>
        </div>

    </nav>

    <section class="home">

        <div class="text">Tambahkan Tiket</div>
        <div class="form-container">
            <form action="../function/functiontiket.php" method="POST" enctype="multipart/form-data">
            <input type="hidden" name="id" value="<?php echo $row['id'];?>">
                <label for="tiket_name">Nama</label>
                <input type="text" id="tiket_name" name="tiket_name" value="<?php echo $nama; ?>" required>

                <label for="gambar">Image:</label>
                <input  <?php if(!isset($_GET['update'])){echo "required";} ?> type="file" id="gambar" name="gambar" accept="image/*">

                <label for="tiket_desc">Deskripsi</label>
                <textarea id="tiket_desc" name="tiket_desc" rows="4" required><?php echo $deskripsi; ?></textarea>

                <label for="tiket_price">Harga Tiket:</label>
                <input type="number" name="tiket_price" id="tiket_price" value="<?php echo $harga; ?>">

                <div class="button-container">
                <?php
                      if(isset($_GET['update'])){
                    ?>
                    <button class="button-up" type="submit" name="action" value="update"><i class='bx bx-add-to-queue'></i>Update</button>
                    <?php
                    }
                    ?>
                    <a class="button-back" href="../dashadmin/dashtiket.php"><i class='bx bx-undo'></i> Back</a>
                </div>
            </form>
        </div>
        
    </section>

    <script>
        const body = document.querySelector('body'),
        sidebar = body.querySelector('nav'),
        toggle = body.querySelector(".toggle"),
        searchBtn = body.querySelector(".search-box"),
        modeSwitch = body.querySelector(".toggle-switch"),
        modeText = body.querySelector(".mode-text");


        toggle.addEventListener("click" , () =>{
            sidebar.classList.toggle("close");
        })

        searchBtn.addEventListener("click" , () =>{
            sidebar.classList.remove("close");
        })

        modeSwitch.addEventListener("click" , () =>{
            body.classList.toggle("dark");
            
            if(body.classList.contains("dark")){
                modeText.innerText = "Light mode";
            }else{
                modeText.innerText = "Dark mode";
                
            }
        });
    </script>

</body>
</html>

<?php mysqli_close($conn); ?>