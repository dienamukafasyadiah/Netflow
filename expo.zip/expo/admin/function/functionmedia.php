<?php
include "../dashadmin/koneksi.php";

        if (isset($_POST['action'])) {

            if ($_POST['action'] == "add") {

                $judul = $_POST['judul_media'];
                $image = $_FILES['image_media']['name'];

                $dir = "../../landing_page/asset/";
                $tmpFile = $_FILES['image_media']['tmp_name'];

                move_uploaded_file($tmpFile, $dir.$image);
                // die();

                $query_sql = "INSERT INTO media (judul_media, image_media)
						  VALUES ('$judul', '$image')";

                if (mysqli_query($conn, $query_sql)) {
                    header("location:../dashadmin/dashmedia.php");
                } else {
                    echo "pendaftaran gagal: " . mysqli_error($conn);
                }
                
            } else if ($_POST['action'] == "update") {

                $judul = $_POST['judul_media'];
                $image = $_FILES['image_media']['name'];

                $id = $_POST['id']; // Tambahkan ini untuk mengambil nilai $id dari form

                $queryShow = "SELECT * FROM media WHERE id ='$id'";
                $sqlShow = mysqli_query($conn, $queryShow);
                $row = mysqli_fetch_array($sqlShow, MYSQLI_ASSOC);

                if ($_FILES['image_media']['name'] == "") {
                    $image = $row['image_media'];
                } else {
                    $image = $_FILES['image_media']['name']; // Tambahkan tanda koma di sini
                }

                $query = "UPDATE media SET judul_media='$judul', image_media='$image' WHERE id='$id'";
                unlink("../../landing_page/asset/" .$row['image_media']);
                move_uploaded_file($_FILES['image_media']['tmp_name'], '../../landing_page/asset/'.$_FILES['image_media']['name']); // Perbaiki 'rmp_name' menjadi 'tmp_name'

                $sql = mysqli_query($conn, $query);

                header("location:../dashadmin/dashmedia.php");
            }
        }

        if(isset($_GET['hapus'])){
            $id = $_GET['hapus'];

            $queryShow = "SELECT * FROM media WHERE id='$id';";
            
            $sqlShow = mysqli_query($conn, $queryShow);
            $row = mysqli_fetch_array($sqlShow, MYSQLI_ASSOC);
            
            unlink("../../aset/" . $row['image_media']);
            
            $query = "DELETE FROM media WHERE id=$id";

            if(mysqli_query($conn,$query)){
                header("location:../dashadmin/dashmedia.php");
            } else{
                echo "Pendaftaran gagal: " . mysqli_error($conn);
            }
        }
           
            
        
?>
