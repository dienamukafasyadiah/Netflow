<?php
include "../dashadmin/koneksi.php";

        if (isset($_POST['action'])) {

            if ($_POST['action'] == "add") {

                $judul = $_POST['judul_blog'];
                $tanggal = $_POST['tanggal'];
                $image = $_FILES['image_blog']['name'];
                $deskripsi = $_POST['deskripsi_blog'];

                $dir = "../../landing_page/asset/";
                $tmpFile = $_FILES['image_blog']['tmp_name'];

                move_uploaded_file($tmpFile, $dir.$image);
                // die();

                $query_sql = "INSERT INTO blog (judul_blog, tanggal, image_blog, deskripsi_blog)
						  VALUES ('$judul', '$tanggal', '$image', '$deskripsi')";

                if (mysqli_query($conn, $query_sql)) {
                    header("location:../dashadmin/dashblog.php");
                } else {
                    echo "pendaftaran gagal: " . mysqli_error($conn);
                }
                
            } else if ($_POST['action'] == "update") {

                $judul = $_POST['judul_blog'];
                $tanggal = $_POST['tanggal'];
                $image = $_FILES['image_blog']['name'];
                $deskripsi = $_POST['deskripsi_blog'];
                $id = $_POST['id']; // Tambahkan ini untuk mengambil nilai $id dari form

                $queryShow = "SELECT * FROM blog WHERE id ='$id'";
                $sqlShow = mysqli_query($conn, $queryShow);
                $row = mysqli_fetch_array($sqlShow, MYSQLI_ASSOC);

                if ($_FILES['image_blog']['name'] == "") {
                    $image = $row['image_blog'];
                } else {
                    $image = $_FILES['image_blog']['name']; // Tambahkan tanda koma di sini
                }

                $query = "UPDATE blog SET judul_blog='$judul', tanggal='$tanggal', image_blog='$image', deskripsi_blog='$deskripsi' WHERE id='$id'";
                unlink("../../landing_page/asset/" .$row['image_blog']);
                move_uploaded_file($_FILES['image_blog']['tmp_name'], '../../landing_page/asset/'.$_FILES['image_blog']['name']); // Perbaiki 'rmp_name' menjadi 'tmp_name'

                $sql = mysqli_query($conn, $query);

                header("location:../dashadmin/dashblog.php");
            }
        }

        if(isset($_GET['hapus'])){
            $id = $_GET['hapus'];

            $queryShow = "SELECT * FROM blog WHERE id='$id';";
            
            $sqlShow = mysqli_query($conn, $queryShow);
            $row = mysqli_fetch_array($sqlShow, MYSQLI_ASSOC);
            
            unlink("../../landing_page/asset/" . $row['image_blog']);
            
            $query = "DELETE FROM blog WHERE id=$id";

            if(mysqli_query($conn,$query)){
                header("location:../dashadmin/dashblog.php");
            } else{
                echo "Pendaftaran gagal: " . mysqli_error($conn);
            }
        }
           
            
        
?>
