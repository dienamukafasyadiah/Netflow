<?php
include "../dashadmin/koneksi.php";

        if (isset($_POST['action'])) {

            if ($_POST['action'] == "add") {

                $judul = $_POST['judul'];
                $image = $_FILES['gambar']['name'];
                $deskripsi = $_POST['deskripsi'];

                $dir = "../../landing_page/asset/";
                $tmpFile = $_FILES['gambar']['tmp_name'];

                move_uploaded_file($tmpFile, $dir.$image);
                // die();

                $query_sql = "INSERT INTO kuliner (judul, gambar,  deskripsi)
						  VALUES ('$judul', '$image', '$deskripsi')";

                if (mysqli_query($conn, $query_sql)) {
                    header("location: ../dashadmin/dashkuliner.php");
                } else {
                    echo "pendaftaran gagal: " . mysqli_error($conn);
                }
                
            } else if ($_POST['action'] == "update") {

                $judul = $_POST['judul'];
                $image = $_FILES['gambar']['name'];
                $deskripsi = $_POST['deskripsi'];
                $id = $_POST['id']; // Tambahkan ini untuk mengambil nilai $id dari form

                $queryShow = "SELECT * FROM kuliner WHERE id ='$id'";
                $sqlShow = mysqli_query($conn, $queryShow);
                $row = mysqli_fetch_array($sqlShow, MYSQLI_ASSOC);

                if ($_FILES['gambar']['name'] == "") {
                    $image = $row['gambar'];
                } else {
                    $image = $_FILES['gambar']['name']; // Tambahkan tanda koma di sini
                }

                $query = "UPDATE kuliner SET judul='$judul', gambar='$image', deskripsi='$deskripsi' WHERE id='$id'";
                unlink("../../landing_page/asset/" .$row['gambar']);
                move_uploaded_file($_FILES['gambar']['tmp_name'], '../../landing_page/asset/'.$_FILES['gambar']['name']); // Perbaiki 'rmp_name' menjadi 'tmp_name'

                $sql = mysqli_query($conn, $query);

                header("location: ../dashadmin/dashkuliner.php");
            }
        }

        if(isset($_GET['hapus'])){
            $id = $_GET['hapus'];

            $queryShow = "SELECT * FROM kuliner WHERE id='$id';";
            
            $sqlShow = mysqli_query($conn, $queryShow);
            $row = mysqli_fetch_array($sqlShow, MYSQLI_ASSOC);
            
            unlink("../../aset/" . $row['gambar']);
            
            $query = "DELETE FROM kuliner WHERE id=$id";

            if(mysqli_query($conn,$query)){
                header("location:../dashadmin/dashkuliner.php");
            } else{
                echo "Pendaftaran gagal: " . mysqli_error($conn);
            }
        }
           
            
        
?>
