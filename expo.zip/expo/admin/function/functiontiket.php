<?php
include "../dashadmin/koneksi.php";

        if (isset($_POST['action'])) {

            if ($_POST['action'] == "add") {

                $nama = $_POST['tiket_name'];
                $image = $_FILES['gambar']['name'];
                $deskripsi = $_POST['tiket_desc'];
                $harga = $_POST['tiket_price'];

                $dir = "../../landing_page/asset/";
                $tmpFile = $_FILES['gambar']['tmp_name'];

                move_uploaded_file($tmpFile, $dir.$image);
                // die();

                $query_sql = "INSERT INTO tiket (tiket_name, gambar,  tiket_desc, tiket_price)
						  VALUES ('$nama', '$image', '$deskripsi', '$harga')";

                if (mysqli_query($conn, $query_sql)) {
                    header("location:../dashadmin/dashtiket.php");
                } else {
                    echo "pendaftaran gagal: " . mysqli_error($conn);
                }
                
            } else if ($_POST['action'] == "update") {

                $nama = $_POST['tiket_name'];
                $image = $_FILES['gambar']['name'];
                $deskripsi = $_POST['tiket_desc'];
                $harga = $_POST['tiket_price'];
                $id = $_POST['id']; // Tambahkan ini untuk mengambil nilai $id dari form

                $queryShow = "SELECT * FROM tiket WHERE id ='$id'";
                $sqlShow = mysqli_query($conn, $queryShow);
                $row = mysqli_fetch_array($sqlShow, MYSQLI_ASSOC);

                if ($_FILES['gambar']['name'] == "") {
                    $image = $row['gambar'];
                } else {
                    $image = $_FILES['gambar']['name']; // Tambahkan tanda koma di sini
                }

                $query = "UPDATE tiket SET tiket_name='$nama', gambar='$image', tiket_desc='$deskripsi' , tiket_price='$harga' WHERE id='$id'";
                unlink("../../landing_page/asset/" .$row['gambar']);
                
                move_uploaded_file($_FILES['gambar']['tmp_name'], '../../landing_page/asset/'.$_FILES['gambar']['name']); // Perbaiki 'rmp_name' menjadi 'tmp_name'

                $sql = mysqli_query($conn, $query);

                header("location:../dashadmin/dashtiket.php");
            }
        }

        if(isset($_GET['hapus'])){
            $id = $_GET['hapus'];

            $queryShow = "SELECT * FROM tiket WHERE id='$id';";
            
            $sqlShow = mysqli_query($conn, $queryShow);
            $row = mysqli_fetch_array($sqlShow, MYSQLI_ASSOC);
            
            unlink("../../landing_page/asset/" . $row['gambar']);
            
            $query = "DELETE FROM tiket WHERE id=$id";

            if(mysqli_query($conn,$query)){
                header("location: ../dashadmin/dashtiket.php");
            } else{
                echo "Pendaftaran gagal: " . mysqli_error($conn);
            }
        }
           
            
        
?>
