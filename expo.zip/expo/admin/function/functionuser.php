<?php
include "../dashadmin/koneksi.php";

        if (isset($_POST['action'])) {

            if ($_POST['action'] == "add") {

                $username = $row['username'];
                $email = $_POST['email'];
                $password = $_POST['password'];
                $password = md5($password);

                $dir = "../../asset/";
                $tmpFile = $_FILES['gambar']['tmp_name'];

                move_uploaded_file($tmpFile, $dir.$image);
                // die();

                $query_sql = "INSERT INTO register (username, email, gambar,  deskripsi)
						  VALUES ('$username', '$email', '$image', '$deskripsi')";

                if (mysqli_query($conn, $query_sql)) {
                    header("location:../dashboard/adminregistrasi.php");
                } else {
                    echo "pendaftaran gagal: " . mysqli_error($conn);
                }
                
            } else if ($_POST['action'] == "update") {

                $username = $row['username'];
                $email = $_POST['email'];
                $password = $_POST['password'];
                $password = md5($password); // Tambahkan ini untuk mengambil nilai $id dari form

                $queryShow = "SELECT * FROM register WHERE id ='$id'";

                $query = "UPDATE register SET judul='$judul', informasi='$informasi', goto='$image', deskripsi='$deskripsi' WHERE id='$id'";

                $sql = mysqli_query($conn, $query);

                header("location:../dashboard/adminUser.php");
            }
        }

        if(isset($_GET['hapus'])){
            $id = $_GET['hapus'];

            $queryShow = "SELECT * FROM register WHERE id='$id';";
            
            $sqlShow = mysqli_query($conn, $queryShow);
            $row = mysqli_fetch_array($sqlShow, MYSQLI_ASSOC);
            
            unlink("../../aset/" . $row['gambar']);
            
            $query = "DELETE FROM register WHERE id=$id";

            if(mysqli_query($conn,$query)){
                header("location:../dashboard/adminUser.php");
            } else{
                echo "Pendaftaran gagal: " . mysqli_error($conn);
            }
        }
           
            
        
?>
