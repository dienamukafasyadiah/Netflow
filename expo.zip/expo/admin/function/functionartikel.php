<?php
include "../dashadmin/koneksi.php";

        if (isset($_POST['action'])) {

            if ($_POST['action'] == "add") {

                $judul = $_POST['judul'];
                $informasi = $_POST['informasi'];
                $image = $_FILES['gambar']['name'];
                $deskripsi = $_POST['deskripsi'];

                $dir = "./../landing_page/asset/";
                $tmpFile = $_FILES['gambar']['tmp_name'];

                move_uploaded_file($tmpFile, $dir.$image);
                // die();

                $query_sql = "INSERT INTO artikel (judul, informasi, gambar,  deskripsi)
						  VALUES ('$judul', '$informasi', '$image', '$deskripsi')";

                if (mysqli_query($conn, $query_sql)) {
                    header("location:../dashadmin/dashblog.php");
                } else {
                    echo "pendaftaran gagal: " . mysqli_error($conn);
                }
                
            } else if ($_POST['action'] == "update") {

                $judul = $_POST['judul'];
                $informasi = $_POST['informasi'];
                $image = $_FILES['gambar']['name'];
                $deskripsi = $_POST['deskripsi'];
                $id = $_POST['id_artikel']; // Tambahkan ini untuk mengambil nilai $id dari form

                $queryShow = "SELECT * FROM artikel WHERE id_artikel ='$id'";
                $sqlShow = mysqli_query($conn, $queryShow);
                $row = mysqli_fetch_array($sqlShow, MYSQLI_ASSOC);

                if ($_FILES['gambar']['name'] == "") {
                    $image = $row['gambar'];
                } else {
                    $image = $_FILES['gambar']['name']; // Tambahkan tanda koma di sini
                }

                $query = "UPDATE artikel SET judul='$judul', informasi='$informasi', gambar='$image', deskripsi='$deskripsi' WHERE id_artikel='$id'";
                unlink("./../landing_page/asset/" .$row['gambar']);
                move_uploaded_file($_FILES['gambar']['tmp_name'], './../landing_page/asset/'.$_FILES['gambar']['name']); // Perbaiki 'rmp_name' menjadi 'tmp_name'

                $sql = mysqli_query($conn, $query);

                header("location:../dashadmin/dashblog.php");
            }
        }

        if(isset($_GET['hapus'])){
            $id = $_GET['hapus'];

            $queryShow = "SELECT * FROM artikel WHERE id_artikel='$id';";
            
            $sqlShow = mysqli_query($conn, $queryShow);
            $row = mysqli_fetch_array($sqlShow, MYSQLI_ASSOC);
            
            unlink("../../aset/" . $row['gambar']);
            
            $query = "DELETE FROM artikel WHERE id_artikel=$id";

            if(mysqli_query($conn,$query)){
                header("location:../dashadmin/dashblog.php");
            } else{
                echo "Pendaftaran gagal: " . mysqli_error($conn);
            }
        }
           
            
        
?>
