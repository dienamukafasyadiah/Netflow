<?php
include "../dashadmin/koneksi.php";
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    
    <!----======== CSS ======== -->
    <link rel="stylesheet" href="../style/addBlog.css">
    <!----===== Boxicons CSS ===== -->
    <link href='https://unpkg.com/boxicons@2.1.1/css/boxicons.min.css' rel='stylesheet'>

    <title>Admin user</title> 
</head>
<body>
    <nav class="sidebar close">
        <header>
            <div class="image-text">
                <span class="image">
                    <img src="../../landing_page/asset/jotasi.png" alt="">
                </span>

                <div class="text logo-text">
                    <span class="name">JOTASI</span>
                    <span class="profession">Jogja Wisata Eksplorasi</span>
                </div>
            </div>

            <i class='bx bx-chevron-right toggle'></i>
        </header>

        <div class="menu-bar">
            <div class="menu">

            <ul class="menu-links">
                    <li class="nav-link">
                        <a href="../dashadmin/admin.php">
                            <i class='bx bx-home-alt icon' ></i>
                            <span class="text nav-text">Dashboard</span>
                        </a>
                    </li>

                    <li class="nav-link">
                        <a href="../dashadmin/dashblog.php">
                            <i class='bx bxl-blogger'></i>
                            <span class="text nav-text">Blog</span>
                        </a>
                    </li>

                    <li class="nav-link">
                        <a href="../dashadmin/dashkuliner.php">
                            <i class='bx bx-bowl-hot'></i>
                            <span class="text nav-text">Kuliner</span>
                        </a>
                    </li>
                    

                    <li class="nav-link">
                        <a href="../dashadmin/dashmedia.php">
                            <i class='bx bx-video-recording'></i>
                            <span class="text nav-text">Media</span>
                        </a>
                    </li>

                    
                    <li class="nav-link">
                        <a href="../dashadmin/dashtiket.php">
                            <i class='bx bx-money-withdraw'></i>
                            <span class="text nav-text">Tiket</span>
                        </a>
                    </li>

                    <li class="nav-link">
                        <a href="../dashadmin/dashuser.php">
                            <i class='bx bx-user'></i>
                            <span class="text nav-text">user</span>
                        </a>
                    </li>

                </ul>
            </div>

            <div class="bottom-content">
                <li class="">
                    <a href="../../landing_page/php/index.php">
                        <i class='bx bx-log-out icon' ></i>
                        <span class="text nav-text">Logout</span>
                    </a>
                </li>
                
            </div>
        </div>

    </nav>

    <section class="home">
        <div class="text">Tambahkan Blog</div>
        
        <div class="form-container">
            <h2>Formulir Blog</h2>
            <form action="../function/functionblog.php" method="POST" enctype="multipart/form-data">
                <label for="judul_blog">Judul</label>
                <input type="text" id="judul_blog" name="judul_blog" required>

                <label for="image_blog">Image:</label>
                <input type="file" id="image_blog" name="image_blog" accept="image/*" required>

                <label for="tanggal">Tanggal:</label>
                <input type="date" id="tanggal" name="tanggal" required>

                <label for="deskripsi_blog">Deskripsi:</label>
                <textarea id="deskripsi_blog" name="deskripsi_blog" rows="4" required></textarea>

                <button type="submit" name="action" value="add" class="button-sub">Submit</button>
                <a href="../dashadmin/dashblog.php" type="submit" class="button-back">Back</a>
            </form>
        </div>
        
    </section>

    
    
    <script>
            const body = document.querySelector('body'),
        sidebar = body.querySelector('nav'),
        toggle = body.querySelector(".toggle"),
        searchBtn = body.querySelector(".search-box"),
        modeSwitch = body.querySelector(".toggle-switch"),
        modeText = body.querySelector(".mode-text");


        toggle.addEventListener("click" , () =>{
            sidebar.classList.toggle("close");
        })

        searchBtn.addEventListener("click" , () =>{
            sidebar.classList.remove("close");
        })
    </script>

</body>
</html>

<?php mysqli_close($conn); ?>