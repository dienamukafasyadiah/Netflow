<?php
include "koneksi.php";
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    
    <!----======== CSS ======== -->
    <link rel="stylesheet" href="../style/media.css">
    
    <!----===== Boxicons CSS ===== -->
    <link href='https://unpkg.com/boxicons@2.1.1/css/boxicons.min.css' rel='stylesheet'>

    <title>Admin user</title> 
</head>
<body>
    <nav class="sidebar close">
        <header>
            <div class="image-text">
                <span class="image">
                    <img src="../../landing_page/asset/jotasi.png" alt="">
                </span>

                <div class="text logo-text">
                    <span class="name">JOTASI</span>
                    <span class="profession">Jogja Wisata Eksplorasi</span>
                </div>
            </div>

            <i class='bx bx-chevron-right toggle'></i>
        </header>

        <div class="menu-bar">
            <div class="menu">

                <ul class="menu-links">
                    <li class="nav-link">
                        <a href="admin.php">
                            <i class='bx bx-home-alt icon' ></i>
                            <span class="text nav-text">Dashboard</span>
                        </a>
                    </li>

                    <li class="nav-link">
                        <a href="dashblog.php">
                            <i class='bx bxl-blogger'></i>
                            <span class="text nav-text">Blog</span>
                        </a>
                    </li>

                    <li class="nav-link">
                        <a href="dashkuliner.php">
                            <i class='bx bx-bowl-hot'></i>
                            <span class="text nav-text">Kuliner</span>
                        </a>
                    </li>
                    

                    <li class="nav-link">
                        <a href="dashmedia.php">
                            <i class='bx bx-video-recording'></i>
                            <span class="text nav-text">Media</span>
                        </a>
                    </li>

                    <li class="nav-link">
                        <a href="dashtiket.php">
                            <i class='bx bx-money-withdraw'></i>
                            <span class="text nav-text">Tiket</span>
                        </a>
                    </li>

                    <li class="nav-link">
                        <a href="dashuser.php">
                            <i class='bx bx-user'></i>
                            <span class="text nav-text">user</span>
                        </a>
                    </li>

                </ul>
            </div>

            <div class="bottom-content">
                <li class="">
                    <a href="../../landing_page/php/index.php">
                        <i class='bx bx-log-out icon' ></i>
                        <span class="text nav-text">Logout</span>
                    </a>
                </li>
                
            </div>
        </div>

    </nav>

    <section class="home">
        <div class="text">Pendaftar (User)</div>

        <!-- Modal -->
        <div class="table-container">
            <table>
                <thead>
                    <tr>
                        <th>Email</th>
                        <th>Username</th>
                        <th>Password</th>
                    </tr>
                </thead>
                <tbody>
                    <?php
                    $result = mysqli_query($conn, "SELECT * FROM register");
                    while ($row = mysqli_fetch_array($result, MYSQLI_ASSOC)) {
                    ?>
                    <tr>
                        <td><?php echo $row['email']; ?></td>
                        <td><?php echo $row['username']; ?></td>
                        <td><?php echo $row['password']; ?></td>
                    </tr>
                    <?php
                    }
                    ?>
                </tbody>
            </table>

        </div>

        <br/> 
        <div class="text">Review Pengunjung </div>

            <div class="table-container">
                <table>
                    <thead>
                        <tr>
                            <th>id</th>
                            <th>Username</th>
                            <th>Review</th>
                        </tr>
                    </thead>
                    <tbody>
                        <?php
                        $result = mysqli_query($conn, "SELECT * FROM review_kuliner");
                        while ($row = mysqli_fetch_array($result, MYSQLI_ASSOC)) {
                        ?>
                        <tr>
                            <td><?php echo $row['id']; ?></td>
                            <td><?php echo $row['userName']; ?></td>
                            <td><?php echo $row['userReview']; ?></td>
                        </tr>
                        <?php
                        }
                        ?>
                    </tbody>
                </table>
            </div>

    </section>

    
   

    <script>
            const body = document.querySelector('body'),
        sidebar = body.querySelector('nav'),
        toggle = body.querySelector(".toggle"),
        searchBtn = body.querySelector(".search-box"),
        modeSwitch = body.querySelector(".toggle-switch"),
        modeText = body.querySelector(".mode-text");


        toggle.addEventListener("click" , () =>{
            sidebar.classList.toggle("close");
        })

        searchBtn.addEventListener("click" , () =>{
            sidebar.classList.remove("close");
        })

        modeSwitch.addEventListener("click" , () =>{
            body.classList.toggle("dark");
            
            if(body.classList.contains("dark")){
                modeText.innerText = "Light mode";
            }else{
                modeText.innerText = "Dark mode";
                
            }
        });
    </script>

</body>
</html>

<?php mysqli_close($conn); ?>