<?php
include "koneksi.php";
?>


<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    
    <!----======== CSS ======== -->
    <link rel="stylesheet" href="../style/admin.css">
    
    <!----===== Boxicons CSS ===== -->
    <link href='https://unpkg.com/boxicons@2.1.1/css/boxicons.min.css' rel='stylesheet'>

    <title>Dashboard Admin</title> 
</head>
<body>
    <nav class="sidebar close">
        <header>
            <div class="image-text">
                <span class="image">
                    <img src="../../landing_page/asset/jotasi.png" alt="">
                </span>

                <div class="text logo-text">
                    <span class="name">JOTASI</span>
                    <span class="profession">Jogja Wisata Eksplorasi</span>
                </div>
            </div>

            <i class='bx bx-chevron-right toggle'></i>
        </header>

        <div class="menu-bar">
            <div class="menu">

                <ul class="menu-links">
                    <li class="nav-link">
                        <a href="admin.php">
                            <i class='bx bx-home-alt icon' ></i>
                            <span class="text nav-text">Dashboard</span>
                        </a>
                    </li>

                    <li class="nav-link">
                        <a href="dashblog.php">
                            <i class='bx bxl-blogger'></i>
                            <span class="text nav-text">Blog</span>
                        </a>
                    </li>

                    <li class="nav-link">
                        <a href="dashkuliner.php">
                            <i class='bx bx-bowl-hot'></i>
                            <span class="text nav-text">Kuliner</span>
                        </a>
                    </li>
                    

                    <li class="nav-link">
                        <a href="dashmedia.php">
                            <i class='bx bx-video-recording'></i>
                            <span class="text nav-text">Media</span>
                        </a>
                    </li>

                    <li class="nav-link">
                        <a href="dashtiket.php">
                            <i class='bx bx-money-withdraw'></i>
                            <span class="text nav-text">Tiket</span>
                        </a>
                    </li>

                    <li class="nav-link">
                        <a href="dashuser.php">
                            <i class='bx bx-user'></i>
                            <span class="text nav-text">user</span>
                        </a>
                    </li>

                </ul>
            </div>

            <div class="bottom-content">
                <li class="">
                    <a href="../../landing_page/php/index.php">
                        <i class='bx bx-log-out icon' ></i>
                        <span class="text nav-text">Logout</span>
                    </a>
                </li>
                
            </div>
        </div>

    </nav>

    <section class="home">
        <div class="text">Dashboard Admin</div>

        <div class="main-skills">
           
            <div class="card">
                        <?php
                        $query1 = mysqli_query($conn, "SELECT COUNT(id) as jumlah FROM blog");
                        $dataBlog = mysqli_fetch_array($query1, MYSQLI_ASSOC);

                        $query2 = mysqli_query($conn, "SELECT COUNT(id_artikel) as jumlah FROM artikel");
                        $dataArtikel = mysqli_fetch_array($query2, MYSQLI_ASSOC);
                        ?>
                        <i class='bx bxl-blogger'></i>
                        <h3><?php echo $dataBlog['jumlah']+$dataArtikel['jumlah'];?></h3>
                        <p>Jumlah Artikel & Blog</p>
                        <a href="dashblog.php" class="text-xs font-weight-bold text-info text-uppercase mt-1">Go to Page</a>
            </div>
            <div class="card">
                        <?php
                        $query = mysqli_query($conn, "SELECT COUNT(id) as jumlah FROM media");
                        $dataMedia = mysqli_fetch_array($query, MYSQLI_ASSOC);

                        ?>
                        <i class='bx bx-video-recording'></i>
                        <h3><?php echo $dataMedia['jumlah'];?></h3>
                        <p>Jumlah Media</p>
                        <a href="dashmedia.php" class="text-xs font-weight-bold text-info text-uppercase mt-1">Go to Page</a>
            </div>

            <div class="card">
                        <?php
                        $query = mysqli_query($conn, "SELECT COUNT(id) as jumlah FROM register");
                        $daraUser = mysqli_fetch_array($query, MYSQLI_ASSOC);

                        ?>
                        <i class='bx bx-user'></i>
                        <h3><?php echo $daraUser['jumlah'];?></h3>
                        <p>Jumlah User</p>
                        <a href="dashuser.php" class="text-xs font-weight-bold text-info text-uppercase mt-1">Go to Page</a>
            </div>

            <div class="card">
                        <?php
                        $query = mysqli_query($conn, "SELECT COUNT(id) as jumlah FROM kuliner");
                        $daraUser = mysqli_fetch_array($query, MYSQLI_ASSOC);

                        ?>
                        <i class='bx bx-bowl-hot'></i>
                        <h3><?php echo $daraUser['jumlah'];?></h3>
                        <p>Jumlah kuliner</p>
                        <a href="dashkuliner.php" class="text-xs font-weight-bold text-info text-uppercase mt-1">Go to Page</a>
            </div>

            <div class="card">
                        <?php
                        $query = mysqli_query($conn, "SELECT COUNT(id) as jumlah FROM review_kuliner");
                        $daraUser = mysqli_fetch_array($query, MYSQLI_ASSOC);

                        ?>
                        <i class='bx bxs-circle-three-quarter' ></i>
                        <h3><?php echo $daraUser['jumlah'];?></h3>
                        <p>Jumlah kuliner</p>
                        <a href="dashkuliner.php" class="text-xs font-weight-bold text-info text-uppercase mt-1">Go to Page</a>
            </div>

    </section>


    <script>
        const body = document.querySelector('body');
        const sidebar = body.querySelector('nav');
        const toggle = body.querySelector(".toggle");
        const searchBtn = body.querySelector(".search-box");
        const modeSwitch = body.querySelector(".toggle-switch");
        const modeText = body.querySelector(".mode-text");

        toggle.addEventListener("click", () => {
        sidebar.classList.toggle("close");
        });

        searchBtn.addEventListener("click", () => {
        sidebar.classList.remove("close");
        });

    </script>

</body>
</html>

<?php mysqli_close($conn); ?>