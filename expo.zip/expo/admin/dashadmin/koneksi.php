<?php
$servername = "localhost";
$username = "root";
$password = "";
$dbname = "jotasi_db";

// Create connection
$conn = mysqli_connect($servername, $username, $password, $dbname);

// Check connection
if (!$conn) {
  die("koneksi gagal: " . mysqli_connect_error());
}
?>
