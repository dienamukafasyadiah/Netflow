<?php
include "koneksi.php";
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    
    <!----======== CSS ======== -->
    <link rel="stylesheet" href="../style/blog.css">
    
    <!----===== Boxicons CSS ===== -->
    <link href='https://unpkg.com/boxicons@2.1.1/css/boxicons.min.css' rel='stylesheet'>

    <title>Admin Blog</title> 
</head>
<body>
    <nav class="sidebar close">
        <header>
            <div class="image-text">
                <span class="image">
                    <img src="../../landing_page/asset/jotasi.png" alt="">
                </span>

                <div class="text logo-text">
                    <span class="name">JOTASI</span>
                    <span class="profession">Jogja Wisata Eksplorasi</span>
                </div>
            </div>

            <i class='bx bx-chevron-right toggle'></i>
        </header>

        <div class="menu-bar">
            <div class="menu">

                <ul class="menu-links">
                    <li class="nav-link">
                        <a href="admin.php">
                            <i class='bx bx-home-alt icon' ></i>
                            <span class="text nav-text">Dashboard</span>
                        </a>
                    </li>

                    <li class="nav-link">
                        <a href="dashblog.php">
                            <i class='bx bxl-blogger'></i>
                            <span class="text nav-text">Blog</span>
                        </a>
                    </li>

                    <li class="nav-link">
                        <a href="dashkuliner.php">
                            <i class='bx bx-bowl-hot'></i>
                            <span class="text nav-text">Kuliner</span>
                        </a>
                    </li>
                    

                    <li class="nav-link">
                        <a href="dashmedia.php">
                            <i class='bx bx-video-recording'></i>
                            <span class="text nav-text">Media</span>
                        </a>
                    </li>

                    <li class="nav-link">
                        <a href="dashtiket.php">
                            <i class='bx bx-money-withdraw'></i>
                            <span class="text nav-text">Tiket</span>
                        </a>
                    </li>

                    <li class="nav-link">
                        <a href="dashuser.php">
                            <i class='bx bx-user'></i>
                            <span class="text nav-text">user</span>
                        </a>
                    </li>
                </ul>
            </div>

            <div class="bottom-content">
                <li class="">
                    <a href="../../landing_page/php/index.php">
                        <i class='bx bx-log-out icon' ></i>
                        <span class="text nav-text">Logout</span>
                    </a>
                </li>
                
            </div>
        </div>

    </nav>

    <section class="home">

        <div class="text">Admin Artikel</div>

         <!-- tombol add -->
         <div class="add-button-container">
            <a href="../addform/addformArtikel.php" type="button" class="add-btn"> <i class='bx bx-add-to-queue'></i> Add Data</a>
        </div>

              <!-- Modal -->
        <div class="table-container">
            <table>
            <thead>
                <tr>
                    <th>Id</th>
                    <th>Judul</th>
                    <th>Image </th>
                    <th>Deskripsi</th>
                    <th>Action 1</th>
                    <th>Action 2</th>
                </tr>
            </thead>
            <tbody>
                <?php
                $i=1;
                $result = mysqli_query($conn, "SELECT * FROM artikel");
                while ($row = mysqli_fetch_array($result, MYSQLI_ASSOC)) {
                ?>
                <tr>
                <td><?php echo $i++; ?></td>
                <td><?php echo $row['judul']; ?></td>
                <td><img src = "../../landing_page/asset/<?php echo $row ["gambar"]; ?>" alt = ""></td>

                <td><?php echo $row['deskripsi']; ?></td>
                <td>
                    <a class="update-btn" href="../editform/editArtikel.php?update=<?php echo $row['id_artikel'];?>" type="button">Update</a>
                </td>
                <td>
                    <a class="delete-btn" href="../function/functionartikel.php?hapus=<?php echo $row['id_artikel'];?>" type="button">Delete</a>
                </td>
                </tr>
                <?php
            }
            ?>
                <!-- Add more rows as needed -->
            </tbody>
            </table>
        </div>

        <div class="text">Admin Blog</div>

         <!-- tombol add -->
         <div class="add-button-container">
            <a href="../addform/addformBlog.php" type="button" class="add-btn"> <i class='bx bx-add-to-queue'></i> Add Data</a>
        </div>

        <!-- Modal -->
        <div class="table-container">
            <table>
                <thead>
                    <tr>
                        <th>id</th>
                        <th>Judul</th>
                        <th>Image </th>
                        <th>Deskripsi </th>
                        <th>Tanggal</th>
                        <th>Action 1</th>
                        <th>Action 2</th>
                    </tr>
                </thead>
                <tbody>
                    <?php
                      $i=1;
                    $result = mysqli_query($conn, "SELECT * FROM blog");
                    while ($row = mysqli_fetch_array($result, MYSQLI_ASSOC)) {
                    ?>
                    <tr>
                        <td><?php echo $i++; ?></td>
                        <td><?php echo $row['judul_blog']; ?></td>
                        <td><img src = "../../landing_page/asset/<?php echo $row ["image_blog"]; ?>" alt = ""></td>
                        <td><?php echo $row['deskripsi_blog']; ?></td>
                        <td><?php echo $row['tanggal']; ?></td>
                        <td>
                            <a class="update-btn" href="../editform/editBlog.php?update=<?php echo $row['id'];?>" type="button">Update</a><br/>
                        </td>
                        <td>
                            <a class="delete-btn" href="../function/functionblog.php?hapus=<?php echo $row['id'];?>" type="button">Delete</a>
                        </td>
                    </tr>
                    <?php
                }
                ?>
                    <!-- Add more rows as needed -->
                </tbody>
            </table>
        </div>
    </section>

    <script>
            const body = document.querySelector('body'),
        sidebar = body.querySelector('nav'),
        toggle = body.querySelector(".toggle"),
        searchBtn = body.querySelector(".search-box"),
        modeSwitch = body.querySelector(".toggle-switch"),
        modeText = body.querySelector(".mode-text");


        toggle.addEventListener("click" , () =>{
            sidebar.classList.toggle("close");
        })

        searchBtn.addEventListener("click" , () =>{
            sidebar.classList.remove("close");
        })

        modeSwitch.addEventListener("click" , () =>{
            body.classList.toggle("dark");
            
            if(body.classList.contains("dark")){
                modeText.innerText = "Light mode";
            }else{
                modeText.innerText = "Dark mode";
                
            }
        });
    </script>

</body>
</html>

<?php mysqli_close($conn); ?>